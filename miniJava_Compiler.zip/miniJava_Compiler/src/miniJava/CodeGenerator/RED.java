package miniJava.CodeGenerator;

import miniJava.CodeGenerator.Base;;

public class RED {
	public int value;
	public Base base;
	
	public RED(int value, Base base) {
		this.value = value;
		this.base = base;
	}
}
