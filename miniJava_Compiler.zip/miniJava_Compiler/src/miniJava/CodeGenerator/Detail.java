package miniJava.CodeGenerator;

public enum Detail {
	ASSIGN, EXPR
}
