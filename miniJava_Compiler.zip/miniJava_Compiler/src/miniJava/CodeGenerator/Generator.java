package miniJava.CodeGenerator;

import java.util.ArrayList;
import mJAM.Disassembler;
import mJAM.Interpreter;
import mJAM.Machine;
import mJAM.ObjectFile;
import mJAM.Machine.Op;
import mJAM.Machine.Prim;
import mJAM.Machine.Reg;
import miniJava.ErrorReporter;
import miniJava.AbstractSyntaxTrees.AST;
import miniJava.AbstractSyntaxTrees.ArrayType;
import miniJava.AbstractSyntaxTrees.AssignStmt;
import miniJava.AbstractSyntaxTrees.BaseType;
import miniJava.AbstractSyntaxTrees.BinaryExpr;
import miniJava.AbstractSyntaxTrees.BlockStmt;
import miniJava.AbstractSyntaxTrees.BooleanLiteral;
import miniJava.AbstractSyntaxTrees.CallExpr;
import miniJava.AbstractSyntaxTrees.CallStmt;
import miniJava.AbstractSyntaxTrees.ClassDecl;
import miniJava.AbstractSyntaxTrees.ClassType;
import miniJava.AbstractSyntaxTrees.Expression;
import miniJava.AbstractSyntaxTrees.FieldDecl;
import miniJava.AbstractSyntaxTrees.IdRef;
import miniJava.AbstractSyntaxTrees.Identifier;
import miniJava.AbstractSyntaxTrees.IfStmt;
import miniJava.AbstractSyntaxTrees.IntLiteral;
import miniJava.AbstractSyntaxTrees.IxAssignStmt;
import miniJava.AbstractSyntaxTrees.IxExpr;
import miniJava.AbstractSyntaxTrees.LiteralExpr;
import miniJava.AbstractSyntaxTrees.MethodDecl;
import miniJava.AbstractSyntaxTrees.NewArrayExpr;
import miniJava.AbstractSyntaxTrees.NewObjectExpr;
import miniJava.AbstractSyntaxTrees.NullLiteral;
import miniJava.AbstractSyntaxTrees.Operator;
import miniJava.AbstractSyntaxTrees.Package;
import miniJava.AbstractSyntaxTrees.ParameterDecl;
import miniJava.AbstractSyntaxTrees.QualRef;
import miniJava.AbstractSyntaxTrees.RefExpr;
import miniJava.AbstractSyntaxTrees.ReturnStmt;
import miniJava.AbstractSyntaxTrees.Statement;
import miniJava.AbstractSyntaxTrees.ThisRef;
import miniJava.AbstractSyntaxTrees.TypeKind;
import miniJava.AbstractSyntaxTrees.UnaryExpr;
import miniJava.AbstractSyntaxTrees.VarDecl;
import miniJava.AbstractSyntaxTrees.VarDeclStmt;
import miniJava.AbstractSyntaxTrees.Visitor;
import miniJava.AbstractSyntaxTrees.WhileStmt;
import miniJava.SyntacticAnalyzer.TokenKind;

public class Generator implements Visitor<Detail, Object> {

	AST finalAST;
	ArrayList<Patcher> fixTable;
	ErrorReporter rep;
	int localVariables; // include vars that are in scopes as well
	int methodVariables; // base method vars
	int mainLocation;
	public String fileName;

	public Generator(AST finalAST, ErrorReporter rep, String fileName) {
		this.finalAST = finalAST;
		this.rep = rep;
		this.fileName = fileName;
		this.fixTable = new ArrayList<Patcher>();
	}

	public void createAssembly() {
		Machine.initCodeGen(); // start process
		finalAST.visit(this, null); // make some statements
		patchLines(); // patch the jumps
	}

	public void patchLines() {
		for (Patcher p : fixTable) {
			Machine.patch(p.offset, p.mD.getRed().value); // patches all the instructions
		}
		disassemble();
	}

	private void disassemble() {
		String objectCodeFileName = fileName.replace(".java", ".mJAM");
		ObjectFile objF = new ObjectFile(objectCodeFileName);
		System.out.print("Writing object code file " + objectCodeFileName + " ... ");
		if (objF.write()) {
			rep.reportError("*** Code Generation error: Can't make object file.");
			return;
		} else {
			System.out.println("SUCCEEDED");
		}

	}

	@Override
	public Object visitPackage(Package prog, Detail arg) {
		int staticVariables = 0;
		for (ClassDecl cD : prog.classDeclList) {
			int instanceVariables = 0;
			for (FieldDecl fD : cD.fieldDeclList) {
				if (fD.isStatic) {
					Machine.emit(Op.PUSH, 1); // pushing up the static variables
					fD.red = new RED(staticVariables, Base.SB);
					staticVariables++;
				} else {
					fD.red = new RED(instanceVariables, Base.OB);
					instanceVariables++;
				}
			}
			cD.red = new RED(cD.fieldDeclList.size() - staticVariables, Base.CB);
		}

		Machine.emit(Machine.Op.LOADL, 0);
		Machine.emit(Machine.Prim.newarr);
		mainLocation = Machine.nextInstrAddr();
		Machine.emit(Machine.Op.CALL, Machine.Reg.CB, -1);
		Machine.emit(Machine.Op.HALT, 0, 0, 0);

		for (ClassDecl cD : prog.classDeclList) {

			for (FieldDecl fD : cD.fieldDeclList)
				fD.visit(this, null);

			cD.visit(this, null);
		}

		return null;
	}

	@Override
	public Object visitClassDecl(ClassDecl cd, Detail arg) {
		for (int i = 0; i < cd.methodDeclList.size(); i++) {
			cd.methodDeclList.get(i).visit(this, null);
		}
		return null;
	}

	@Override
	public Object visitFieldDecl(FieldDecl fd, Detail arg) {
		fd.type.visit(this, null);
		return null;
	}

	@Override
	public Object visitMethodDecl(MethodDecl md, Detail arg) {
		methodVariables = 3;

		md.red = new RED(Machine.nextInstrAddr(), Base.CB);

		if (md.id.spelling.equals("main"))
			Machine.patch(mainLocation, Machine.nextInstrAddr());

		int paramSize = md.parameterDeclList.size();
		int i = -1 * paramSize; // set the parameters and visit them appropriately
		for (ParameterDecl pD : md.parameterDeclList) {
			pD.red = new RED(i, Base.ARG);
			pD.visit(this, null);
			i++;
		}

		for (Statement st : md.statementList) {
			st.visit(this, null);
		}

		if (md.type.typeKind != TypeKind.VOID) {
			Machine.emit(Machine.Op.RETURN, 1, 0, paramSize);
		} else {
			Machine.emit(Machine.Op.RETURN, 0, 0, paramSize);
		}

		return null;
	}

	@Override
	public Object visitParameterDecl(ParameterDecl pd, Detail arg) {
		pd.type.visit(this, null);
		return null;
	}

	@Override
	public Object visitVarDecl(VarDecl decl, Detail arg) {
		decl.red = new RED(methodVariables, Base.LB);
		methodVariables++; // this is for the new vairable that you just added in the method
		decl.type.visit(this, null);
		return null;
	}

	@Override
	public Object visitBaseType(BaseType type, Detail arg) {
		return null;
	}

	@Override
	public Object visitClassType(ClassType type, Detail arg) {
		return null;
	}

	@Override
	public Object visitArrayType(ArrayType type, Detail arg) {
		return null;
	}

	@Override
	public Object visitBlockStmt(BlockStmt stmt, Detail arg) {
		localVariables = 0;
		for (Statement st : stmt.sl) {
			st.visit(this, null); // if it's a var decl stmt, then the local Variable count will be increased.
		}
		if (localVariables > 0) {
			methodVariables -= localVariables;
			Machine.emit(Op.POP, localVariables);
		}
		return null;
	}

	@Override
	public Object visitVardeclStmt(VarDeclStmt stmt, Detail arg) {
		localVariables++; // youre making a new variable each time
		stmt.varDecl.visit(this, null); // you have added to the runtime entity
		stmt.initExp.visit(this, null);
		return null;
	}

	@Override
	public Object visitAssignStmt(AssignStmt stmt, Detail arg) {
		// check static first
		// checkStatic field declaration first
		// IdRef x = 3;
		// QualRef this.id.id = 3 or id.id.id = 3;
		
		if (stmt.ref.decl.staticField) {
			stmt.val.visit(this, null);
			Machine.emit(Op.STORE, Machine.Reg.SB, stmt.ref.decl.getRed().value);
		} else if (stmt.ref instanceof IdRef) {
			stmt.val.visit(this, null);
			IdRef tempRef = (IdRef) stmt.ref;
			if (tempRef.decl instanceof FieldDecl) { // if it's something global
				FieldDecl tempField = (FieldDecl) tempRef.decl;
				if (tempField.isStatic) {
					Machine.emit(Op.STORE, Reg.SB, tempField.getRed().value);
				} else {
					Machine.emit(Op.STORE, Reg.OB, tempField.getRed().value);
				}
			} else { // now check if it's something local
				Machine.emit(Op.STORE, Reg.LB, stmt.ref.decl.getRed().value);
			}

		} else if (stmt.ref instanceof QualRef) {
			stmt.ref.visit(this, Detail.ASSIGN);
			stmt.val.visit(this, null);
			Machine.emit(Prim.fieldupd);
		}

		return null;
	}

	private void putStackRef(QualRef ref) {
		if (ref.id.decl.getRed() != null) {
			ArrayList<Integer> refs = new ArrayList<Integer>();
			refs.add(ref.id.decl.getRed().value);

			while (ref.ref instanceof QualRef) {
				ref = (QualRef) ref.ref;
				refs.add(ref.decl.getRed().value);
			}

			ref.ref.visit(this, null); // its finally not a qref
			int refS = refs.size();

			for (int j = 0; j < refS; j++) {
				Machine.emit(Op.LOADL, refs.get(refs.size() - 1));
				refs.remove(refs.size() - 1);

				if (j + 1 < refS)
					Machine.emit(Prim.fieldref);
			}
		}
	}

	@Override
	public Object visitIxAssignStmt(IxAssignStmt stmt, Detail arg) {
		// check static field declaration first
		// IdRef Id[]
		// QualRef this.id.id[] or id.id.id[]

		if (stmt.ref instanceof IdRef) {

//			IdRef tempRef = (IdRef) stmt.ref;
//			if (tempRef.decl instanceof FieldDecl) { // if it's something global
//				FieldDecl tempField = (FieldDecl) tempRef.decl;
//				if (tempField.isStatic) {
//					Machine.emit(Op.LOAD, Reg.SB, tempField.getRed().value);
//				} else {
//					Machine.emit(Op.LOAD, Reg.OB, tempField.getRed().value);
//				}
//			} else { // now check if it's something local
//				Machine.emit(Op.LOAD, Reg.LB, stmt.ref.decl.getRed().value);
//			}

			stmt.ref.visit(this, null);

		} else if (stmt.ref instanceof QualRef) {
			//putStackRef((QualRef) stmt.ref);
			stmt.ref.visit(this, null);

		} else {
			stmt.ref.visit(this, null);
		}

		stmt.ix.visit(this, null);
		stmt.exp.visit(this, null);
		Machine.emit(Prim.arrayupd);
		return null;
	}

	@Override
	public Object visitCallStmt(CallStmt stmt, Detail arg) {
		// Idref id() or this.id();
		// identify by the id, if it's this, it doesn't matter. check if it's static
		MethodDecl md = (MethodDecl) stmt.methodRef.decl;
		
		if (md.type.typeKind == TypeKind.VOID) {
			for (Expression args : stmt.argList) {
				args.visit(this, null);
			}

			if (stmt.methodRef instanceof QualRef && md.name.equals("println")) {
				Machine.emit(Prim.putintnl);
			} else {
				if (md.isStatic) {
					fixTable.add(new Patcher(Machine.nextInstrAddr(), md));
					Machine.emit(Op.CALL, Reg.CB, -1);
				} else {
					if (stmt.methodRef instanceof QualRef) {
						QualRef qr = (QualRef) stmt.methodRef;
						qr.visit(this, null);
					} else {
						stmt.methodRef.visit(this, null);
					}
					int cA = Machine.nextInstrAddr();
					Machine.emit(Op.CALLI, Reg.CB, 0);
					fixTable.add(new Patcher(cA, md));
				}

			}
		}

		if (md.type.typeKind != TypeKind.VOID) {
			Machine.emit(Op.POP, 1);
		}
		return null;
	}

	@Override
	public Object visitReturnStmt(ReturnStmt stmt, Detail arg) {
		if (stmt.returnExpr != null) {
			stmt.returnExpr.visit(this, null);
		}
		return null;
	}

	@Override
	public Object visitIfStmt(IfStmt stmt, Detail arg) {
		stmt.cond.visit(this, null);
		int ifBegin = Machine.nextInstrAddr();
		Machine.emit(Machine.Op.JUMPIF, 0, Machine.Reg.CB, -1);

		stmt.thenStmt.visit(this, null);
		int afterThen = Machine.nextInstrAddr();
		Machine.emit(Op.JUMP, Machine.Reg.CB, -1);

		int afterElse = Machine.nextInstrAddr();
		Machine.patch(ifBegin, afterElse);

		if (stmt.elseStmt != null) {
			stmt.elseStmt.visit(this, null);
		}

		Machine.patch(afterThen, Machine.nextInstrAddr());

		return null;
	}

	@Override
	public Object visitWhileStmt(WhileStmt stmt, Detail arg) {

		int whileBegin = Machine.nextInstrAddr();
		stmt.cond.visit(this, null);
		int whileCond = Machine.nextInstrAddr();
		Machine.emit(Machine.Op.JUMPIF, 0, Machine.Reg.CB, -1);

		stmt.body.visit(this, null);
		Machine.emit(Op.JUMP, Machine.Reg.CB, whileBegin);

		int whileEnd = Machine.nextInstrAddr();
		Machine.patch(whileCond, whileEnd);

		return null;
	}

	@Override
	public Object visitUnaryExpr(UnaryExpr expr, Detail arg) {
		expr.expr.visit(this, null); // load the expression

		switch (expr.operator.kind) {
		case NOT:
			Machine.emit(Prim.not);
			break;
		case NEGATE:
			Machine.emit(Prim.neg);
			break;
		default:
			System.out.println(expr.operator.kind);
			rep.reportError("*** line " + expr.posn.s + ": " + "Error in visitUnaryExpr: Reached the default case.");
		}
		return null;
	}

	@Override
	public Object visitBinaryExpr(BinaryExpr expr, Detail arg) {
		expr.left.visit(this, null);
		expr.right.visit(this, null);
		expr.operator.visit(this, null);
		return null;
	}

	@Override
	public Object visitRefExpr(RefExpr expr, Detail arg) {
		// QualRef this.id.id or id.id.id
		// Idref id
		// check static field

		if (expr.ref.findDeclaration().staticField) {
			Machine.emit(Op.LOAD, Machine.Reg.SB, expr.ref.decl.getRed().value);
		} else if (expr.ref instanceof IdRef || expr.ref instanceof ThisRef || expr.ref instanceof QualRef) {
			expr.ref.visit(this, null);
		}

		return null;
	}

	@Override
	public Object visitIxExpr(IxExpr expr, Detail arg) {
		// QualRef this.id.id[] or id.id.id[]
		// idref id[]
		// check static field

		expr.ref.visit(this, null);
		expr.ixExpr.visit(this, null);
		Machine.emit(Prim.arrayref);

		return null;
	}

	@Override
	public Object visitCallExpr(CallExpr expr, Detail arg) {
		// Idref()
		// QualRef this.id() or id.id()
		// Check static field, all in the method base
		MethodDecl md = (MethodDecl) expr.functionRef.decl;
		for (int i = 0; i < expr.argList.size(); i++) {
			expr.argList.get(i).visit(this, null); // load the argument values in order hopefully
		}

		if (expr.functionRef instanceof QualRef && md.name.equals("println")) {
			Machine.emit(Prim.putintnl);
		} else {
			if (md.isStatic) {
				fixTable.add(new Patcher(Machine.nextInstrAddr(), md));
				Machine.emit(Op.CALL, Reg.CB, -1);
			} else {
				if (expr.functionRef instanceof QualRef) {
					QualRef qr = (QualRef) expr.functionRef;
					qr.ref.visit(this, null);
				} else {
					Machine.emit(Op.LOADA, Machine.Reg.OB, 0);
				}
				int cA = Machine.nextInstrAddr();
				Machine.emit(Op.CALLI, Reg.CB, 0);
				fixTable.add(new Patcher(cA, md));
			}
		}

		return null;
	}

	@Override
	public Object visitLiteralExpr(LiteralExpr expr, Detail arg) {
		expr.lit.visit(this, null);
		return null;
	}

	@Override
	public Object visitNewObjectExpr(NewObjectExpr expr, Detail arg) {
		Machine.emit(Op.LOADL, -1);
		Machine.emit(Op.LOADL, expr.classtype.className.decl.getRed().value);
		Machine.emit(Prim.newobj);
		return null;
	}

	@Override
	public Object visitNewArrayExpr(NewArrayExpr expr, Detail arg) {
		expr.sizeExpr.visit(this, null);
		Machine.emit(Prim.newarr);
		return null;
	}

	@Override
	public Object visitThisRef(ThisRef ref, Detail arg) {
		Machine.emit(Op.LOADA, Reg.OB, 0);
		return null;
	}

	@Override
	public Object visitIdRef(IdRef ref, Detail arg) {
		if ((ref.decl instanceof FieldDecl && ((FieldDecl) ref.decl).isStatic) || ref.id.decl.staticField) {
			Machine.emit(Op.LOAD, Reg.SB, ref.id.decl.getRed().value);
		} else if (ref.decl instanceof FieldDecl) {
			Machine.emit(Op.LOAD, Reg.OB, ref.id.decl.getRed().value);
		} else if (ref.id.decl.getRed() != null) {
			if (ref.id.decl.staticField) {
				Machine.emit(Op.LOAD, Reg.SB, ref.id.decl.getRed().value);
			} else {
				if (!(ref.id.decl instanceof MethodDecl)) {
					Machine.emit(Op.LOAD, Reg.LB, ref.id.decl.getRed().value);
				}
			}
		}

		return null;
	}

	@Override
	public Object visitQRef(QualRef ref, Detail arg) {
		if (arg == Detail.ASSIGN) {
			putStackRef(ref);
			return null;
		}
		
		if (ref.id.decl.isLen) {
			IdRef ref2 = null;
			
			if (ref.ref instanceof QualRef) {
				putStackRef(ref);
				QualRef temp = (QualRef) ref.ref;
				while (temp.ref instanceof QualRef) {
					temp = (QualRef) temp.ref;
				}
				ref2 = (IdRef) temp.ref;
			} else {
				ref2 = (IdRef) ref.ref;
			}
			
			if (ref2.decl instanceof FieldDecl && ((FieldDecl) ref2.decl).isStatic) {
				Machine.emit(Op.LOAD, Reg.SB, ref2.id.decl.getRed().value);
			} else if (ref2.decl instanceof FieldDecl) {
				Machine.emit(Op.LOAD, Reg.OB, ref2.id.decl.getRed().value);
			} else if (ref2.id.decl.getRed() != null) {
				if (ref2.id.decl.staticField) {
					Machine.emit(Op.LOAD, Reg.SB, ref2.id.decl.getRed().value);
				} else {
					if (!(ref2.id.decl instanceof MethodDecl)) {
						Machine.emit(Op.LOAD, Reg.LB, ref2.id.decl.getRed().value);
					}
				}
			}
			Machine.emit(Prim.arraylen);
		} else {
			if (ref.id.decl.getRed() != null) {
				putStackRef(ref);
				Machine.emit(Prim.fieldref);
			}
		}
		return null;
	}

	@Override
	public Object visitIdentifier(Identifier id, Detail arg) {
		// done in the visitIdRef
		return null;
	}

	@Override
	public Object visitOperator(Operator op, Detail arg) {
		if (op.kind == TokenKind.LT) {
			Machine.emit(Prim.lt);
		} else if (op.kind == TokenKind.GT) {
			Machine.emit(Prim.gt);
		} else if (op.kind == TokenKind.EQUALSEQUALS) {
			Machine.emit(Prim.eq);
		} else if (op.kind == TokenKind.LTE) {
			Machine.emit(Prim.le);
		} else if (op.kind == TokenKind.GTE) {
			Machine.emit(Prim.ge);
		} else if (op.kind == TokenKind.DIS) {
			Machine.emit(Prim.or);
		} else if (op.kind == TokenKind.CON) {
			Machine.emit(Prim.and);
		} else if (op.kind == TokenKind.ADDITIVE) {
			Machine.emit(Prim.add);
		} else if (op.kind == TokenKind.NEGATE) {
			Machine.emit(Prim.sub);
		} else if (op.kind == TokenKind.MULTIPLY) {
			Machine.emit(Prim.mult);
		} else if (op.kind == TokenKind.DIVIDE) {
			Machine.emit(Prim.div);
		} else if (op.kind == TokenKind.NOTEQUALS) {
			Machine.emit(Prim.ne);
		} else {
			rep.reportError(
					"*** line " + op.posn.s + ": " + "Error in visitOperator: No proper operator in code generation");
		}

		return null;
	}

	@Override
	public Object visitIntLiteral(IntLiteral num, Detail arg) {
		Machine.emit(Op.LOADL, Integer.parseInt(num.spelling));
		return null;
	}

	@Override
	public Object visitBooleanLiteral(BooleanLiteral bool, Detail arg) {
		if (bool.kind == TokenKind.TRUE) {
			Machine.emit(Op.LOADL, 1);
		} else if (bool.kind == TokenKind.FALSE) {
			Machine.emit(Op.LOADL, 0);
		}
		return null;
	}

	@Override
	public Object visitNullLiteral(NullLiteral nul, Detail arg) {
		Machine.emit(Op.LOADL, 0);
		return null;
	}

}
