package miniJava.CodeGenerator;

public enum Base {
	LB, CB, SB, OB, ARG
}
