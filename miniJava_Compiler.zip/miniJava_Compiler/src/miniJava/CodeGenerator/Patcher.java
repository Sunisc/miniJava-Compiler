package miniJava.CodeGenerator;

import miniJava.AbstractSyntaxTrees.MethodDecl;

public class Patcher {
	int offset;
	MethodDecl mD;

	public Patcher(int offset, MethodDecl mD) {
		this.offset = offset;
		this.mD = mD;
	}
}
