package miniJava.SyntacticAnalyzer;

import java.io.IOException;
import java.io.InputStream;

import miniJava.SyntacticAnalyzer.TokenKind;
import miniJava.ErrorReporter;

public class Scanner {
	private InputStream inputStream;
	private ErrorReporter reporter;

	private char currentChar;
	private StringBuilder currentSpelling;

	// true when end of line is found
	private boolean eot = false;
	private int line;

	public Scanner(InputStream inputStream, ErrorReporter reporter) {
		this.inputStream = inputStream;
		this.reporter = reporter;
		this.line = 1;
		// initialize scanner state
		readChar();
	}

	public Token scan() {
		SourcePosition pos = new SourcePosition();
		pos.s = line;
		pos.f = line;
		
		skipSpaceAndJumps();

		currentSpelling = new StringBuilder();
		TokenKind kind = scanToken();

		String spelling = currentSpelling.toString();

		return new Token(kind, spelling, pos);
	}

	public TokenKind scanToken() {
		// remove the comments
		
		while (currentChar == '/') {
			if (currentChar == '/') {
				skipIt();
				if (currentChar == '/') {
					skipIt();
					while (true) {
						if (eot) 
							break;
						if (currentChar == '\n' || currentChar == '\r') {
							skipIt();
							break;
						} else {
							skipIt();
						}
					}
				} else if (currentChar == '*') {
					skipIt();
					while (true) {
						if (eot) {
							scanError("Cannot recognize char: " + currentChar + " in input");
							return TokenKind.ERROR;
						}
						if (currentChar == '*') {
							skipIt();
							if (currentChar == '/') {
								skipIt();
								break;
							}
						}
						if (currentChar != '*') skipIt();
					}

				} else {
					currentSpelling.append("/");
					return TokenKind.DIVIDE;
				}
			}
			skipSpaceAndJumps();
		}

		skipSpaceAndJumps();

		while (currentChar == '\\') {
			skipIt();
			if (currentChar == 't' || currentChar == 'n' || currentChar == 'r') skipIt();
			skipSpaceAndJumps();
		}

		if (eot)
			return (TokenKind.EOT);

		// scan Token
		switch (currentChar) {
		case '>':
			takeIt();
			if (currentChar == '=') {
				takeIt();
				return TokenKind.GTE;
			} else {
				return TokenKind.GT;
			}

		case '<':
			takeIt();
			if (currentChar == '=') {
				takeIt();
				return TokenKind.LTE;
			} else {
				return TokenKind.LT;
			}

		case '=':
			takeIt();
			if (currentChar == '=') {
				takeIt();
				return TokenKind.EQUALSEQUALS;
			} else {
				return TokenKind.EQUALS;
			}

		case '!':
			takeIt();
			if (currentChar == '=') {
				takeIt();
				return TokenKind.NOTEQUALS;
			} else {
				return TokenKind.NOT;
			}

		case '&':
			takeIt();
			if (currentChar == '&') {
				takeIt();
				return TokenKind.CON;
			}
			return TokenKind.ERROR;

		case '|':
			takeIt();
			if (currentChar == '|') {
				takeIt();
				return TokenKind.DIS;
			} else {
				return TokenKind.ERROR;
			}

		case '+':
			takeIt();
			return TokenKind.ADDITIVE;

		case '-':
			takeIt();
			return TokenKind.NEGATE;

		case '*':
			takeIt();
			return TokenKind.MULTIPLY;

		case '(':
			takeIt();
			return (TokenKind.LPAREN);

		case ')':
			takeIt();
			return (TokenKind.RPAREN);

		case '[':
			takeIt();
			return (TokenKind.LBRACE);

		case ']':
			takeIt();
			return (TokenKind.RBRACE);

		case '{':
			takeIt();
			return (TokenKind.LBRACKET);

		case '}':
			takeIt();
			return (TokenKind.RBRACKET);

		case '.':
			takeIt();
			return (TokenKind.DOT);

		case ';':
			takeIt();
			return (TokenKind.SEMI);

		case ',':
			takeIt();
			return (TokenKind.COMMA);

		case '0':
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
			while (isDigit(currentChar))
				takeIt();
			return (TokenKind.NUM);
		}

		if (isLetter()) {
			takeIt();
		} else if (currentChar == '_') {
			takeIt();
			if (currentChar != 'P') {
				return TokenKind.ERROR;
			} else {
				takeIt();
			}
		} else {
			return TokenKind.ERROR;
		}

		while (isLetter() || isDigit(currentChar) || currentChar == '_') {
			takeIt();
		}

		switch (currentSpelling.toString()) {
		case "int":
			return TokenKind.INT;
		case "if":
			return TokenKind.IF;
		case "class":
			return TokenKind.CLASS;
		case "public":
			return TokenKind.PUBLIC;
		case "private":
			return TokenKind.PRIVATE;
		case "static":
			return TokenKind.STATIC;
		case "void":
			return TokenKind.VOID;
		case "boolean":
			return TokenKind.BOOLEAN;
		case "this":
			return TokenKind.THIS;
		case "return":
			return TokenKind.RETURN;
		case "else":
			return TokenKind.ELSE;
		case "while":
			return TokenKind.WHILE;
		case "true":
			return TokenKind.TRUE;
		case "false":
			return TokenKind.FALSE;
		case "new":
			return TokenKind.NEW;
		case "null":
			return TokenKind.NULL;
		default:
			if (!currentSpelling.toString().isEmpty()) {
				return TokenKind.ID;
			} else if (!eot) {
				scanError("Unrecognized character '" + currentChar + "' in input");
				return (TokenKind.ERROR);
			}
			return TokenKind.ERROR;
		}

	}

	private boolean isLetterLower() {
		String s = Character.toString(currentChar);
		if (s.matches("[a-z]+")) {
			return true;
		}
		return false;
	}

	private boolean isLetter() {
		String s = Character.toString(currentChar);
		if (s.matches("[a-zA-Z]+")) {
			return true;
		}
		return false;
	}

	private void takeIt() {
		currentSpelling.append(currentChar);
		nextChar();
	}

	private void skipIt() {
		nextChar();
	}

	private boolean isDigit(char c) {
		return (c >= '0') && (c <= '9');
	}

	private void scanError(String m) {
		reporter.reportError("Scan Error:  " + m);
	}

	private final static char eolUnix = '\n';
	private final static char eolWindows = '\r';

	private void nextChar() {
		if (!eot)
			readChar();
	}

	private void readChar() {
		try {
			int c = inputStream.read();
			currentChar = (char) c;
			if (currentChar == '\n')
				line++;
			if (c == -1) {
				eot = true;
			}
		} catch (IOException e) {
			scanError("I/O Exception!");
			eot = true;
		}
	}
	
	private void skipSpaceAndJumps() {
		while (!eot && (!eot
				&& (currentChar == '\n' || currentChar == '\t' || currentChar == ' ' || currentChar == '\r'))) {
			skipIt();
		}
	}
	
	private TokenKind removeAllTypesofComs() {
		while (currentChar == '/') {
			if (currentChar == '/') {
				skipIt();
				if (currentChar == '/') {
					skipIt();
					while (true) {
						if (eot) {
							break;
						}
						if (currentChar == '\n' || currentChar == '\r') {
							skipIt();
							break;
						} else {
							skipIt();
						}
					}
				} else if (currentChar == '*') {
					skipIt();
					while (true) {
						if (eot) {
							scanError("Cannot recognize char: " + currentChar + " in input");
							return TokenKind.ERROR;
						}
						if (currentChar == '*') {
							skipIt();
							if (currentChar == '/') {
								skipIt();
								break;
							}
						}
						if (currentChar != '*') skipIt();
					}

				} else {
					currentSpelling.append("/");
					return TokenKind.DIVIDE;
				}
			}
			skipSpaceAndJumps();
		}
		return null;

	}

}
