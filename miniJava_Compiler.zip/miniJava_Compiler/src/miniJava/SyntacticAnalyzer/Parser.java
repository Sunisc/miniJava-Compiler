package miniJava.SyntacticAnalyzer;

import miniJava.SyntacticAnalyzer.TokenKind;
import miniJava.SyntacticAnalyzer.Parser.SyntaxError;
import miniJava.ErrorReporter;
import miniJava.AbstractSyntaxTrees.*;
import miniJava.AbstractSyntaxTrees.Package;
import miniJava.SyntacticAnalyzer.Scanner;
import miniJava.SyntacticAnalyzer.Token;

public class Parser {
	private Scanner scanner;
	private ErrorReporter reporter;
	private Token token;
	private boolean trace = true;
	private SourcePosition posn;
	ParameterDeclList pList;


	public Parser(Scanner scanner, ErrorReporter reporter) {
		this.scanner = scanner;
		this.reporter = reporter;
		posn = new SourcePosition();
	}

	class SyntaxError extends Error {
		private static final long serialVersionUID = 1L;
	}

	public Package parse() {
		Package pAST = null;
		token = scanner.scan();
		System.out.println(token.kind);
		try {
			pAST = parseProgram();
		} catch (SyntaxError e) {

		}
		return pAST;
	}

	// (ClassDeclaration)* eot
	private Package parseProgram() throws SyntaxError {
		s(posn); 
		Package pAST = null;
		ClassDeclList classList = new ClassDeclList();

		if (token.kind == TokenKind.CLASS) {
			while (token.kind == TokenKind.CLASS) {
				ClassDecl classDecl = parseClassDeclaration();
				classList.add(classDecl);
			}
			pAST = new Package(classList, posn);
		} else if (token.kind != TokenKind.EOT) {
			parseError("Invalid Token Kind " + token.kind);
		} else {
			pAST = new Package(classList, posn);
		}
		accept(TokenKind.EOT);
		f(posn);
		return new Package(classList, posn);
	}

	// class id { (FieldDeclaration | MethodDeclaration)* }
	public ClassDecl parseClassDeclaration() throws SyntaxError {
		ClassDecl cD_AST = null;
		FieldDeclList fieldList = new FieldDeclList();
		MethodDeclList methodList = new MethodDeclList();

		FieldDecl fieldDecl = null;
		MethodDecl methodDecl = null;
		
		SourcePosition classDeclPos = new SourcePosition();
		s(classDeclPos);

		if (token.kind == TokenKind.CLASS) {
			acceptIt();
			Identifier name = new Identifier(token);
			String nameS = token.spelling;
			accept(TokenKind.ID);
			accept(TokenKind.LBRACKET);
			while (token.kind != TokenKind.RBRACKET) {
				SourcePosition dPos = new SourcePosition();
				s(dPos);
				boolean priv = false;
				boolean stat = false;
				priv = parseVisibility();
				stat = parseAccess();
				if (token.kind == TokenKind.VOID) {
					TypeDenoter type = new BaseType(TypeKind.VOID, token.posn);
					acceptIt();
					Identifier mName = new Identifier(token);
					String mS = token.spelling;
					accept(TokenKind.ID);
					accept(TokenKind.LPAREN);
					methodDecl = parseMethod(priv, stat, type, mS, dPos);
					methodDecl.staticField = stat;
					methodDecl.id = mName;
					methodDecl.id.decl = methodDecl;
					methodList.add(methodDecl);
				} else {
					TypeDenoter type = parseType();
					Identifier fName = new Identifier(token);
					String fS = token.spelling;
					accept(TokenKind.ID);
					if (token.kind == TokenKind.SEMI) {
						acceptIt();
						f(dPos);
						fieldDecl = new FieldDecl(priv, stat, type, fS, dPos);
						fieldDecl.staticField = stat;
						fieldDecl.id = fName;
						fieldDecl.id.decl = fieldDecl;
						fieldList.add(fieldDecl);
					} else {
						accept(TokenKind.LPAREN);
						methodDecl = parseMethod(priv, stat, type, fS, dPos);
						methodDecl.staticField = stat;
						methodDecl.id = fName;
						methodDecl.id.decl = methodDecl;
						methodList.add(methodDecl);
					}
				}
			}
			accept(TokenKind.RBRACKET);
			f(classDeclPos);
			cD_AST = new ClassDecl(nameS, fieldList, methodList, classDeclPos);
			cD_AST.id = name;
		}
		return cD_AST;
	}

	public MethodDecl parseMethod(boolean priv, boolean stat, TypeDenoter type, String mName, SourcePosition posn)
			throws SyntaxError {
		ParameterDeclList paraList = new ParameterDeclList();
		StatementList statementList = new StatementList();
		if (token.kind != TokenKind.RPAREN) {
			pList = new ParameterDeclList();
			paraList = parseParameterList();
		}
		accept(TokenKind.RPAREN);
		accept(TokenKind.LBRACKET);
		while (token.kind != TokenKind.RBRACKET) {
			statementList.add(parseStatement());
		}
		accept(TokenKind.RBRACKET);
		f(posn);
		return new MethodDecl(new FieldDecl(priv, stat, type, mName, posn), paraList, statementList, posn);
	}

	public boolean parseVisibility() throws SyntaxError {
		switch (token.kind) {
		case PUBLIC:
			acceptIt();
			return false;
		case PRIVATE:
			acceptIt();
			return true;
		default:
			return false;
		}
	}

	public boolean parseAccess() throws SyntaxError {
		if (token.kind == TokenKind.STATIC) {
			acceptIt();
			return true;
		}
		return false;
	}

	public TypeDenoter parseType() throws SyntaxError {
		SourcePosition tPos = new SourcePosition();
		s(tPos);
		TypeDenoter type;
		if (token.kind == TokenKind.BOOLEAN) {
			acceptIt();
			f(tPos);
			type = new BaseType(TypeKind.BOOLEAN, tPos);
			return type;
		} else if (token.kind == TokenKind.INT) {
			acceptIt();
			if (token.kind == TokenKind.LBRACE) {
				acceptIt();
				accept(TokenKind.RBRACE);
				f(tPos);
				type = new BaseType(TypeKind.INT, tPos);
				return new ArrayType((type), tPos);
			}
			return new BaseType(TypeKind.INT, tPos);
		} else if (token.kind == TokenKind.ID) {
			Identifier id = new Identifier(token);
			acceptIt();
			if (token.kind == TokenKind.LBRACE) {
				acceptIt();
				accept(TokenKind.RBRACE);
				f(tPos);
				return new ArrayType(new ClassType(id, tPos), tPos);
			}
			f(tPos);
			return new ClassType(id, tPos);
		}
		f(tPos);
		parseError("Error in parseType");
		return new BaseType(TypeKind.ERROR, tPos);
	}

	public ParameterDeclList parseParameterList() throws SyntaxError {
		SourcePosition pPos = new SourcePosition();
		s(pPos);
		TypeDenoter type = parseType();
		Identifier id = new Identifier(token);
		String idS = token.spelling;
		accept(TokenKind.ID);
		f(pPos);
		ParameterDecl currentDecl = new ParameterDecl(type, idS, pPos);
		pList.add(currentDecl);

		while (token.kind == TokenKind.COMMA) {
			acceptIt();
			s(pPos);
			type = parseType();
			id = new Identifier(token);
			idS = token.spelling;
			accept(TokenKind.ID);
			f(pPos);
			currentDecl = new ParameterDecl(type, idS, pPos);
			pList.add(currentDecl);
		}
		return pList;
	}

	public ExprList parseArgumentList() throws SyntaxError {
		ExprList list = new ExprList();
		list.add(parseExpression());

		while (token.kind == TokenKind.COMMA) {
			acceptIt();
			list.add(parseExpression());
		}

		return list;
	}

	public Statement parseStatement() throws SyntaxError {
		Statement statement = null;
		SourcePosition stPos = new SourcePosition();
		s(stPos);
		switch (token.kind) {
		case RETURN:
			acceptIt();
			if (token.kind != TokenKind.SEMI) {
				Expression returnExpr;
				returnExpr = parseExpression();
				accept(TokenKind.SEMI);
				f(stPos);
				statement = new ReturnStmt(returnExpr, stPos);
				break;
			}
			accept(TokenKind.SEMI);
			f(stPos);
			statement = new ReturnStmt(null, stPos);
			break;
		case IF:
			Expression ifExpr;
			acceptIt();
			accept(TokenKind.LPAREN);
			ifExpr = parseExpression();
			accept(TokenKind.RPAREN);
			Statement then = parseStatement();
			if (token.kind == TokenKind.ELSE) {
				acceptIt();
				Statement els = parseStatement();
				//f(stPos);
				statement = new IfStmt(ifExpr, then, els, stPos);
				break;
			}
			//f(stPos);
			statement = new IfStmt(ifExpr, then, stPos);
			f(stPos);
			break;
		case WHILE:
			Expression whileExpr;
			Statement whileBody;
			acceptIt();
			accept(TokenKind.LPAREN);
			whileExpr = parseExpression();
			accept(TokenKind.RPAREN);
			whileBody = parseStatement();
			f(stPos);
			statement = new WhileStmt(whileExpr, whileBody, stPos);
			break;
		case LBRACKET:
			StatementList l = new StatementList();
			acceptIt();
			while (token.kind != TokenKind.RBRACKET) {
				l.add(parseStatement());
			}
			accept(TokenKind.RBRACKET);
			f(stPos);
			statement = new BlockStmt(l, stPos);
			break;
		case ID:
			Identifier fID = new Identifier(token);
			acceptIt();
			boolean isType = false;
			// Identifier sID = null;
			Reference ref = null;
			VarDecl decl = null;
			Expression expr = null;
			SourcePosition vPos = new SourcePosition();
			// IxExpr ixExpr = null;

			// check for ids before you do = or (. Start with type.

			switch (token.kind) {
			// check for second id
			case ID:
				// start with type id which could be id id
				Identifier sID = new Identifier(token);
				String sID_spelling = token.spelling;
				acceptIt();
				vPos.s = fID.posn.s;
				vPos.f = sID.posn.f;
				decl = new VarDecl(new ClassType(fID, fID.posn), sID_spelling, vPos);
				isType = true;
				break;
			case LBRACE:
				acceptIt();
				if (token.kind != TokenKind.RBRACE) {// iX Ref Reference [Expression]
					SourcePosition rPos = new SourcePosition();
					expr = parseExpression();
					accept(TokenKind.RBRACE);
					rPos.s = stPos.s;
					f(rPos);
					ref = new IdRef(fID, fID.posn);
					// expr = new IxExpr(ref, temp, posn);
					break;
				}
				accept(TokenKind.RBRACE); // array Type id [] id
				// if (token.kind == TokenKind.ID) {
				sID = new Identifier(token);
				String secondIdSpelling = token.spelling;
				accept(TokenKind.ID);
				vPos.s = fID.posn.s;
				vPos.f = sID.posn.f;
				isType = true;
				decl = new VarDecl(new ArrayType(new ClassType(fID, fID.posn), fID.posn), secondIdSpelling, vPos);
				break;
			// }
//					if (token.kind != TokenKind.EQUALS || token.kind != TokenKind.ID)
//						parseError("Incorrect char: " + token.kind);
			case DOT:
				SourcePosition iPos = new SourcePosition();
				iPos.s = fID.posn.s;
				f(iPos);
				ref = new IdRef(fID, fID.posn);
				while (token.kind == TokenKind.DOT) {
					SourcePosition qPos = new SourcePosition();
					qPos.s = iPos.f;
					acceptIt();
					if (token.kind == TokenKind.THIS)
						parseError("You can't have a this after a dot");

					Identifier newId = new Identifier(token);
					accept(TokenKind.ID);
					f(iPos);
					ref = new QualRef(ref, newId, iPos);
				}
				if (token.kind == TokenKind.LBRACE) {
					acceptIt();
					// expr = new IxExpr(ref, parseExpression(), posn);
					expr = parseExpression();
					accept(TokenKind.RBRACE);
				}
				break;
			default:
				ref = new IdRef(fID, fID.posn);
				break;
			}
			if (token.kind == TokenKind.EQUALS) {
				SourcePosition aPos = new SourcePosition();
				aPos.s = fID.posn.s;
				acceptIt();
				Expression assign = parseExpression();
				accept(TokenKind.SEMI);
				f(aPos);
				f(stPos);
				if (ref != null) {
					if (expr != null) {
						statement = new IxAssignStmt(ref, expr, assign, stPos);
					} else {
						statement = new AssignStmt(ref, assign, stPos);
					}
				} else {
					statement = new VarDeclStmt(decl, assign, stPos);

				}

			} else if (isType == false) {
				if (token.kind == TokenKind.LPAREN && expr == null) {
					SourcePosition cPos = new SourcePosition();
					cPos.s = fID.posn.s;
					acceptIt();
					ExprList args = new ExprList();
					if (token.kind != TokenKind.RPAREN) {
						args = parseArgumentList();
					}
					accept(TokenKind.RPAREN);
					accept(TokenKind.SEMI);
					f(cPos);
					f(stPos);
					statement = new CallStmt(ref, args, stPos);
				}
			} else {
//				parseError("Can't parse: " + token.spelling);
				ref = new IdRef(fID, fID.posn);
			}
			break;
		case THIS:
			SourcePosition tPos = new SourcePosition();
			tPos = token.posn;
			accept(TokenKind.THIS);
			Reference thisR = new ThisRef(tPos);
			Expression ixExpr2 = null;

			switch (token.kind) {
			case DOT:
				SourcePosition iPos = new SourcePosition();
				iPos.s = stPos.s;
				while (token.kind == TokenKind.DOT) {
					acceptIt();
					if (token.kind == TokenKind.THIS) {
						parseError("Invalid token" + token.kind);
					}
					Identifier id2 = new Identifier(token);
					accept(TokenKind.ID);
					f(iPos);
					f(tPos);
					thisR = new QualRef(thisR, id2, tPos);
				}
				if (token.kind == TokenKind.LBRACE) {
					acceptIt();
					// ixExpr2 = new IxExpr(thisR, parseExpression(), posn);
					ixExpr2 = parseExpression();
					accept(TokenKind.RBRACE);
				}
				break;
			case LBRACE:
				acceptIt();
				ixExpr2 = parseExpression();
				accept(TokenKind.RBRACE);
				break;
			default:
				break;
			}

			switch (token.kind) {
			case LPAREN:
				accept(TokenKind.LPAREN);
				ExprList args = new ExprList();
				if (token.kind != TokenKind.RPAREN)
					args = parseArgumentList();

				accept(TokenKind.RPAREN);
				accept(TokenKind.SEMI);
				f(stPos);
				statement = new CallStmt(thisR, args, stPos);
				break;
			case EQUALS:
				accept(TokenKind.EQUALS);
				Expression assigned = parseExpression();
				accept(TokenKind.SEMI);
				f(stPos);
				if (ixExpr2 != null) {
					statement = new IxAssignStmt(thisR, ixExpr2, assigned, stPos);
				} else {
					statement = new AssignStmt(thisR, assigned, stPos);
				}
				break;
			default:
				parseError("Error parsing statement:" + token.spelling);
				break;
			}
			break;

		case INT:
		case BOOLEAN:
			SourcePosition vPos2 = new SourcePosition();
			s(vPos2);
			TypeDenoter type = parseType();
			Identifier id = new Identifier(token);
			String spl = id.spelling;
			accept(TokenKind.ID);
			f(vPos2);
			accept(TokenKind.EQUALS);
			Expression varExp = parseExpression();
			accept(TokenKind.SEMI);
			VarDecl temp = new VarDecl(type, spl, id.posn);
			f(stPos);
			statement = new VarDeclStmt(temp, varExp, stPos);
			break;
		default:
			parseError("Error in ParseStatement");
			break;
		}

		return statement;
	}

	public Expression parseExpression() throws SyntaxError {
		// start with DIS
		SourcePosition ePos = new SourcePosition();
		s(ePos);
		Expression expr = null;
		expr = parseCon();
		while (token.kind == TokenKind.DIS) {
			Operator op = new Operator(token);
			acceptIt();
			Expression expr2 = parseCon();
			f(ePos);
			expr = new BinaryExpr(op, expr, expr2, ePos);
		}

		return expr;
	}

	public Expression parseCon() throws SyntaxError {
		SourcePosition cPos = new SourcePosition();
		s(cPos);
		Expression expr = null;
		expr = parseEq();
		while (token.kind == TokenKind.CON) {
			Operator op = new Operator(token);
			acceptIt();
			Expression expr2 = parseEq();
			f(cPos);
			expr = new BinaryExpr(op, expr, expr2, cPos);
		}
		return expr;
	}

	public Expression parseEq() throws SyntaxError {
		SourcePosition cPos = new SourcePosition();
		s(cPos);
		Expression expr = null;
		expr = parseRel();
		while (token.kind == TokenKind.EQUALSEQUALS || token.kind == TokenKind.NOTEQUALS) {
			Operator op = new Operator(token);
			acceptIt();
			Expression expr2 = parseRel();
			f(cPos);
			expr = new BinaryExpr(op, expr, expr2, cPos);
		}

		return expr;
	}

	public Expression parseRel() throws SyntaxError {
		SourcePosition cPos = new SourcePosition();
		s(cPos);
		Expression expr = null;
		expr = parseAdd();
		while (token.kind == TokenKind.GT || token.kind == TokenKind.GTE || token.kind == TokenKind.LT || token.kind == TokenKind.LTE) {
			Operator op = new Operator(token);
			acceptIt();
			Expression expr2 = parseAdd();
			f(cPos);
			expr = new BinaryExpr(op, expr, expr2, cPos);
		}

		return expr;
	}

	public Expression parseAdd() throws SyntaxError {
		SourcePosition cPos = new SourcePosition();
		s(cPos);
		Expression expr = null;
		expr = parseMult();
		while (token.kind == TokenKind.ADDITIVE || token.kind == TokenKind.NEGATE) {
			Operator op = new Operator(token);
			acceptIt();
			Expression expr2 = parseMult();
			f(cPos);
			expr = new BinaryExpr(op, expr, expr2, cPos);
		}
		return expr;
	}

	public Expression parseMult() throws SyntaxError {
		SourcePosition cPos = new SourcePosition();
		s(cPos);
		Expression expr = null;
		expr = parseUn();
		while (token.kind == TokenKind.MULTIPLY || token.kind == TokenKind.DIVIDE) {
			Operator op = new Operator(token);
			acceptIt();
			Expression expr2 = parseUn();
			f(cPos);
			expr = new BinaryExpr(op, expr, expr2, cPos);
		}
		return expr;
	}

	public Expression parseUn() throws SyntaxError {
		SourcePosition cPos = new SourcePosition();
		s(cPos);
		Expression expr = null;

		if (token.kind == TokenKind.NOT || token.kind == TokenKind.NEGATE) {
			// while (token.kind == TokenKind.NEGATE || token.kind == TokenKind.NOT) {
			Operator op = new Operator(token);
			acceptIt();
			// Expression expr2 = parseUn();
			f(cPos);
			expr = new UnaryExpr(op, parseUn(), cPos);
			// }
		} else {
			expr = parseFirstExpr();
		}
		return expr;
	}

	public Expression parseFirstExpr() throws SyntaxError {
		SourcePosition fPos = new SourcePosition();
		Expression expression = null;
		s(fPos);
		switch (token.kind) {
		case TRUE:
			BooleanLiteral b = new BooleanLiteral(token);
			acceptIt();
			f(fPos);
			expression = new LiteralExpr(b, fPos);
			break;
		case FALSE:
			BooleanLiteral c = new BooleanLiteral(token);
			acceptIt();
			f(fPos);
			expression = new LiteralExpr(c, fPos);
			break;
		case NUM:
			IntLiteral d = new IntLiteral(token);
			acceptIt();
			f(fPos);
			expression = new LiteralExpr(d, fPos);
			break;
		case NULL:
			NullLiteral e = new NullLiteral(token);
			acceptIt();
			f(fPos);
			expression = new LiteralExpr(e, fPos);
			break;
		case NEW:
			accept(TokenKind.NEW);

			switch (token.kind) {
			case ID:
				Identifier id = new Identifier(token);
				acceptIt();
				if (token.kind == TokenKind.LPAREN) {
					acceptIt();
					accept(TokenKind.RPAREN);
					f(fPos);
					expression = new NewObjectExpr(new ClassType(id, id.posn), fPos);
				} else if (token.kind == TokenKind.LBRACE) {
					accept(TokenKind.LBRACE);
					Expression temp = parseExpression();
					accept(TokenKind.RBRACE);
					f(fPos);
					expression = new NewArrayExpr(new ClassType(id, id.posn), temp, fPos);
				} else {
					parseError("You need either an ( or a [ after a new id");
				}
				break;
			case INT:
				SourcePosition iPos = token.posn;
				accept(TokenKind.INT);
				accept(TokenKind.LBRACE);
				Expression temp = parseExpression();
				accept(TokenKind.RBRACE);
				f(fPos);
				expression = new NewArrayExpr(new BaseType(TypeKind.INT, iPos), temp, fPos);
				break;
			default:
				parseError("Error failing the num case: " + token);
				break;
			}

			break;
		case LPAREN:
			acceptIt();
			expression = parseExpression();
			accept(TokenKind.RPAREN);
			break;
		case ID:
		case THIS:
			Identifier id = null;
			Reference ref = null;
			Expression ixExpression = null;

			switch (token.kind) {
			case ID:
				// if it equals id
				id = new Identifier(token); // get the identifier
				accept(TokenKind.ID);
				ref = new IdRef(id, id.posn);
				if (token.kind == TokenKind.LBRACE) { // id [Expression], must have expression in it
					accept(TokenKind.LBRACE);
					ixExpression = parseExpression(); // parse expression
					accept(TokenKind.RBRACE);
					f(fPos);
					ref = new IdRef(id, id.posn); // create a new id reference, with the id type
					expression = new IxExpr(ref, ixExpression, fPos); // make an ixexpr, since you have id[expr],
																		// nothing
																		// can follow it
				} else if (token.kind == TokenKind.LPAREN) { // u can have an argument list
					accept(TokenKind.LPAREN);
					ExprList args = new ExprList();
					if (token.kind != TokenKind.RPAREN) {
						args = parseArgumentList();
					}
					accept(TokenKind.RPAREN);
					f(fPos);
					expression = new CallExpr(ref, args, fPos);
				} else if (token.kind == TokenKind.DOT) { // else if it's a dot, then start loopin
					while (token.kind == TokenKind.DOT) {
						acceptIt();
						if (token.kind == TokenKind.THIS) { // can't have a this. only in the beginning
							parseError("You can't have a this after a dot: " + token);
						}
						Identifier newID = new Identifier(token); // make another identifier, since you have a dot,
						accept(TokenKind.ID); // accept it
						f(fPos);
						ref = new QualRef(ref, newID, fPos); // keep appending it basically
					}

					switch (token.kind) {
					case LBRACE: // if after a bunch of id.id.id[expr] you get an expression
						acceptIt();
						ixExpression = parseExpression();
						accept(TokenKind.RBRACE);
						f(fPos);
						expression = new IxExpr(ref, ixExpression, fPos);
						break;
					case LPAREN:
						accept(TokenKind.LPAREN);
						ExprList args = new ExprList();
						if (token.kind != TokenKind.RPAREN) {
							args = parseArgumentList();
						}
						accept(TokenKind.RPAREN);
						f(fPos);
						expression = new CallExpr(ref, args, fPos);
						break;
					default:
						f(fPos);
						expression = new RefExpr(ref, fPos);
						break;
					}

					// parseError("You can't have a id. without nothing after it:" + token);
				} else {
					f(fPos);
					expression = new RefExpr(new IdRef(id, id.posn), fPos); // return just the base expression with
																			// just id
				}
				break;

			case THIS:
				// now start with the case when there's a this
				SourcePosition tPos = token.posn;
				accept(TokenKind.THIS);
				ref = new ThisRef(tPos);
				// now check if you have a lbrace. this [expr]
				if (token.kind == TokenKind.LBRACE) {
					acceptIt();
					ixExpression = parseExpression();
					accept(TokenKind.RBRACE);
					f(fPos);
					expression = new IxExpr(ref, ixExpression, fPos);
				} else if (token.kind == TokenKind.LPAREN) {
					accept(TokenKind.LPAREN);
					ExprList args = new ExprList();
					if (token.kind != TokenKind.RPAREN) {
						args = parseArgumentList();
					}
					accept(TokenKind.RPAREN);
					f(fPos);
					expression = new CallExpr(ref, args, fPos);
				} else if (token.kind == TokenKind.DOT) { // this.id.id.id
					while (token.kind == TokenKind.DOT) {
						acceptIt();
						if (token.kind == TokenKind.THIS) {
							parseError("You can't do this.this: " + token);
						}
						Identifier id2 = new Identifier(token);
						accept(TokenKind.ID);
						f(fPos);
						ref = new QualRef(ref, id2, fPos);
					}
					switch (token.kind) {
					case LBRACE: // if after a bunch of id.id.id[expr] you get an expression
						acceptIt();
						ixExpression = parseExpression();
						accept(TokenKind.RBRACE);
						f(fPos);
						expression = new IxExpr(ref, ixExpression, fPos);
						break;
					case LPAREN:
						accept(TokenKind.LPAREN);
						ExprList args = new ExprList();
						if (token.kind != TokenKind.RPAREN) {
							args = parseArgumentList();
						}
						accept(TokenKind.RPAREN);
						f(fPos);
						expression = new CallExpr(ref, args, fPos);
						break;
					default:
						f(fPos);
						expression = new RefExpr(ref, fPos);
						break;
					}
					// parseError("You can't have a this. without nothing after it:" + token);
				} else {
					f(fPos);
					expression = new RefExpr(ref, fPos); // you just have a this
				}
				break;
			default:
				break;
			}

			//expression = new RefExpr(ref, posn);
			break;
		default:
			parseError("Didn't have correct expression");
			break;
		}

		return expression;
	}

	private void acceptIt() throws SyntaxError {
		accept(token.kind);
	}

	private void accept(TokenKind expectedTokenKind) throws SyntaxError {
		if (token.kind == expectedTokenKind) {
			if (trace)
				pTrace();
			token = scanner.scan();
		} else
			parseError("expecting '" + expectedTokenKind + "' but found '" + token.kind + "'");
	}

	private void parseError(String e) throws SyntaxError {
		reporter.reportError("Parse error: " + e);
		throw new SyntaxError();
	}

	private void pTrace() {
		StackTraceElement[] stl = Thread.currentThread().getStackTrace();
		for (int i = stl.length - 1; i > 0; i--) {
			if (stl[i].toString().contains("parse"))
				System.out.println(stl[i]);
		}
		System.out.println("accepting: " + token.kind + " (\"" + token.spelling + "\")");
		System.out.println();
	}
	
	private void s(SourcePosition pos) {
		pos.s = token.posn.s;
	}
	
	private void f(SourcePosition pos) {
		pos.f = token.posn.f;
	}
}
