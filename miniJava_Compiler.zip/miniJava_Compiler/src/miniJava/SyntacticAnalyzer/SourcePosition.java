package miniJava.SyntacticAnalyzer;

public class SourcePosition {
	public int s, f;

	public SourcePosition() {
		s = 0;
		f = 0;
	}

	public SourcePosition(int s, int f) {
		this.s = s;
		this.f = f;
	}

	public String toString() {
		return "(" + this.s + ", " + this.f + ")";
	}

}
