package miniJava.ContextualAnalyzer;

public enum Work {
	NORMAL, MEMBER, METHOD
}
