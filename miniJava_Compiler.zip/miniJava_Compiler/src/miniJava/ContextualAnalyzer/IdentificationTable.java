package miniJava.ContextualAnalyzer;

import miniJava.AbstractSyntaxTrees.*;
import miniJava.SyntacticAnalyzer.SourcePosition;
import miniJava.SyntacticAnalyzer.Token;
import miniJava.SyntacticAnalyzer.TokenKind;

import java.util.HashMap;
import java.util.Stack;

public class IdentificationTable {
	Stack<HashMap<String, Declaration>> fullTable;
	HashMap<String, Declaration> smolTable;
	HashMap<String, Declaration> tbl1;
	HashMap<String, Declaration> tbl2;
	MethodDeclList pSM;
	MemberDecl lnF;
	ParameterDeclList lnPar;
	MethodDecl putintlM;
	ClassDecl psDecl, sysD, strD;
	Identifier psId, sysId;
	FieldDeclList sysFlds;
	FieldDecl oF;
	
	public IdentificationTable() {
		fullTable = new Stack<HashMap<String, Declaration>>();
		smolTable = new HashMap<String, Declaration>();
		generateGen();
		enterGen(putintlM, psDecl, oF, sysD, strD);
	}

	public boolean enter(String id, Declaration decl) {
		if (!smolTable.containsKey(id)) {
			smolTable.put(id, decl);
			return true;
		} else {
			return false;
		}
	}

	public HashMap<String, Declaration> getSmol() {
		return smolTable;
	}

	public void openScope() {
		smolTable = new HashMap<String, Declaration>();
		fullTable.add(smolTable);
	}

	public void closeScope() {
		fullTable.pop();
		smolTable = fullTable.peek();
	}

	public int getLvl() {
		return fullTable.size() > 0 ? fullTable.size() - 1 : null;
	}

	public HashMap<String, Declaration> getTopTable() {
		return this.smolTable;
	}

	public boolean idExistsAtTop(String id) {
		if (smolTable.containsKey(id))
			return true;
		return false;
	}

	public Declaration retrieve(String id) {
		for (int i = fullTable.size() - 1; i >= 0; i--) {
			if (fullTable.get(i).containsKey(id)) {
				return fullTable.get(i).get(id);
			}
		}
		return null;
	}

	public Declaration getClass(String id) {
		for (int i = fullTable.size() - 1; i >= 0; i--) {
			if (fullTable.get(i).containsKey(id) && fullTable.get(i).get(id) instanceof ClassDecl) {
				return fullTable.get(i).get(id);
			}
		}
		return null;
	}

	private void generateGen() {
		openScope();
		
		pSM = new MethodDeclList();
		lnF = new FieldDecl(false, false, new BaseType(TypeKind.VOID, null), "println", null);
		lnPar = new ParameterDeclList();
		lnPar.add(new ParameterDecl(new BaseType(TypeKind.INT, null), "n", null));
		putintlM = new MethodDecl(lnF, lnPar, new StatementList(), null);
		pSM.add(putintlM);
		psDecl = new ClassDecl("_PrintStream", new FieldDeclList(), pSM, null);
		psId = new Identifier(new Token(TokenKind.ID, "_PrintStream", null));
		psDecl.type = new ClassType(psId, new SourcePosition());

		sysId = new Identifier(new Token(TokenKind.ID, "System", null));
		sysFlds = new FieldDeclList();
		oF = new FieldDecl(false, true, new ClassType(psId, null), "out", null);
		sysFlds.add(oF);
		sysD = new ClassDecl("System", sysFlds, new MethodDeclList(), null);
		sysD.type = new ClassType(sysId, new SourcePosition());

		strD = new ClassDecl("String", new FieldDeclList(), new MethodDeclList(), null);
		strD.type = new BaseType(TypeKind.UNSUPPORTED, null);		
	}
	
	public Declaration getMethod(String id) {
		for (int i = fullTable.size() - 1; i >= 0; i--) {
			if (fullTable.get(i).containsKey(id) && fullTable.get(i).get(id) instanceof MethodDecl) {
				return fullTable.get(i).get(id);
			}
		}
		return null;
	}

	public Declaration getMember(String id) {
		for (int i = fullTable.size() - 1; i >= 0; i--) {
			if (fullTable.get(i).containsKey(id) && fullTable.get(i).get(id) instanceof MemberDecl) {
				return fullTable.get(i).get(id);
			}
		}
		return null;
	}

	private void enterGen(MethodDecl printlnMethod, ClassDecl psDecl, FieldDecl outField, ClassDecl systemDecl,
			ClassDecl StringDecl) {
		enter("_PrintStream", psDecl);
		enter("System", systemDecl);
		enter("String", StringDecl);

		openScope();
		enter("println", printlnMethod);
		enter("out", outField);
	}
	
	private void print() {
		
	}

	public void rotate(int lvl1, int lvl) {		
        tbl1 = fullTable.get(lvl1);
        tbl2 = fullTable.get(lvl);
		fullTable.set(lvl1, tbl2);
		fullTable.set(lvl, tbl1);
	}

}
