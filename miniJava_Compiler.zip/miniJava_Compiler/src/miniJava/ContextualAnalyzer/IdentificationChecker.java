package miniJava.ContextualAnalyzer;

import java.util.ArrayList;
import java.util.HashMap;

import miniJava.*;
import miniJava.AbstractSyntaxTrees.*;
import miniJava.AbstractSyntaxTrees.Package;

public class IdentificationChecker implements Visitor<Work, Object> {

	private AST ast;
	public ErrorReporter rep;
	public IdentificationTable table;

	private ClassDecl selectedClass;
	private boolean staticMethod;
	private String declaringVariable;

	private HashMap<String, Declaration> classes;
	private HashMap<String, HashMap<String, Declaration>> cFields;
	private HashMap<String, HashMap<String, Declaration>> cMethods;
	private HashMap<ClassDecl, Integer> counter = new HashMap<>();
	private FieldDecl arr = new FieldDecl(false, false, new BaseType(TypeKind.INT, null), "length",
			null);
	private ArrayList<String> methodVariables;

	private int mainCount = 0;

	private int spaces = 0;

	public IdentificationChecker(AST ast, ErrorReporter reporter, IdentificationTable tbl) {
		this.ast = ast;
		this.rep = reporter;
		this.table = tbl;

		classes = new HashMap<String, Declaration>();
		cFields = new HashMap<String, HashMap<String, Declaration>>();
		cMethods = new HashMap<String, HashMap<String, Declaration>>();
	}

	public AST check() {
		ast.visit(this, Work.NORMAL);
		if (mainCount > 1 || mainCount == 0) {
			rep.reportError( "*** line " + ast.posn.s + ": " + "Misformed main, no main, or more than one main.");
		}
		return ast;
	}

	@Override
	public Object visitPackage(Package prog, Work type) {
//		System.out.println(getString(spaces) + "visitPackage");
		ClassDeclList classDecls = prog.classDeclList;

		table.openScope(); // +1 to fullTable

		for (ClassDecl cD : classDecls) {
			if (cD.name.startsWith("_")) {
				rep.reportError("*** line " + cD.posn.s + ": " + "Can't have _ in start of class name.");
				return null;
			}
			if (!table.enter(cD.name, cD)) {
				rep.reportError("*** line " + cD.posn.s + ": " + "Duplicate of " + cD.name);
				return null;
			}
		}
		
		for (ClassDecl cD : classDecls) {
			classes.put(cD.name, cD);
			cFields.put(cD.name, new HashMap<String, Declaration>());
			cMethods.put(cD.name, new HashMap<String, Declaration>());
			table.openScope();
			for (FieldDecl fD : cD.fieldDeclList) {
				fD.cD = cD;
				cFields.get(cD.name).put(fD.name, fD);
				if (!table.enter(fD.name, fD)) {
					rep.reportError("*** line " + fD.id.posn.f + ": " + "Duplicate member decl (field)");
					return null;
				}
			}
			for (MethodDecl mD : cD.methodDeclList) {
				mD.cD = cD;
				cMethods.get(cD.name).put(mD.name, mD);
				if (!table.enter(mD.name, mD)) {
					rep.reportError("*** line " + mD.id.posn.s + ": " + "Duplicate member decl (method)");
					return null;
				}
			}
			counter.put(cD, table.getLvl());
		}
		
		int t = table.getLvl();
		for (ClassDecl cD : classDecls) {
			selectedClass = cD;
			table.rotate(counter.get(cD), t);
			cD.visit(this, Work.NORMAL);
		}

		table.closeScope();
//		System.out.println(getString(spaces) + "visitPackage\t\t\tDONE");

		return null;
	}

	@Override
	public Object visitClassDecl(ClassDecl cd, Work type) {// this is basically the first class, that you switched to
		spaces++; // the top
//		System.out.println(getString(spaces) + "visitClassDecl");

		for (FieldDecl fD : cd.fieldDeclList) {
			fD.visit(this, Work.NORMAL);
		}

		for (MethodDecl mD : cd.methodDeclList) {
			isItTheOnlyOne(mD);
			mD.visit(this, Work.NORMAL);
		}

//		System.out.println(getString(spaces) + "visitClassDecl\t\t\tDONE");
		spaces--;
		// table.printStack();
		return null;
	}

	private void isItTheOnlyOne(MethodDecl md) {
		if (md.name.equals("main")) {
			if (!md.isPrivate && md.isStatic && md.type.typeKind == TypeKind.VOID) {
				if (md.parameterDeclList.size() == 1 && md.parameterDeclList.get(0).type instanceof ArrayType) {
					ArrayType arr = (ArrayType) md.parameterDeclList.get(0).type;
					if (arr.eltType instanceof ClassType) {
						if (((ClassType) arr.eltType).className.spelling.equals("String")) {
							mainCount += 1;
							md.isMethodMain = true;
						}
					}
				}
			}
		}
	}

	@Override
	public Object visitFieldDecl(FieldDecl fd, Work type) {
		spaces++;
//		System.out.println(getString(spaces) + "visitFieldDecl");
		fd.type.visit(this, Work.NORMAL); // type references, what does this line of code do?
//		System.out.println(getString(spaces) + "visitingFieldDeclaration\t\t\tDONE");
		spaces--;
		return null;
	}

	@Override
	public Object visitMethodDecl(MethodDecl md, Work type) {
		spaces++;

//		System.out.println(getString(spaces) + "visitMethodDecl");
		md.type.visit(this, Work.NORMAL); // type references

		// open a scope for the method. add to the top of the stack, right after the
		// current class?
		staticMethod = md.isStatic;
		methodVariables = new ArrayList<String>();

		table.openScope();

		for (ParameterDecl pd : md.parameterDeclList) // adding in the visit to the table
			pd.visit(this, Work.NORMAL);

		for (Statement stmt : md.statementList)
			stmt.visit(this, Work.NORMAL);

		table.closeScope();
//		System.out.println(getString(spaces) + "visitMethodDecl\t\t\tDONE");
		spaces--;

		return null;
	}

	@Override
	public Object visitParameterDecl(ParameterDecl pd, Work type) {
		spaces++;
//		System.out.println(getString(spaces) + "visitParameterDecl");

		pd.type.visit(this, Work.NORMAL);
		if (methodVariables.contains(pd.name)) {
			rep.reportError("*** line " + pd.posn.s + ": "
					+ "The current method variables list already has a parameter with similar name.");
			return null;
		} else {
			methodVariables.add(pd.name);

		}

		if (!table.enter(pd.name, pd)) {
			rep.reportError("*** line " + pd.posn.s + ": " + "duplicate declaration of parameter");
			return null;
		}

//		System.out.println(getString(spaces) + "visitParameterDecl\t\tDONE");
		spaces--;

		return null;
	}

	@Override
	public Object visitVarDecl(VarDecl decl, Work type) {
		spaces++;
//		System.out.println(getString(spaces) + "visitVarDecl");

		// check if type is def
		decl.type.visit(this, Work.NORMAL);
		// decl.setIdBinding();

		if (methodVariables.contains(decl.name)) {
			rep.reportError(
					"*** line " + decl.posn.s + ": " + "duplicate declaration of variable decl in methodVariables");
			return null;
		} else {
			methodVariables.add(decl.name);
		}

		if (!table.enter(decl.name, decl)) {
			rep.reportError("*** line " + decl.posn.s + ": " + "duplicate declaration of variable decl in table");
			return null;

		}
//		System.out.println(getString(spaces) + "visitVarDecl\t\t\tDONE");
		spaces--;

		// table.printStack();

		return null;
	}

	@Override
	public Object visitBaseType(BaseType type, Work type2) {
		spaces++;
//		System.out.println(getString(spaces) + "visitBaseType");
//		System.out.println(getString(spaces) + "visitBaseType\t\t\tDONE");
		spaces--;
		return null;
	}

	@Override
	public Object visitClassType(ClassType type, Work type2) {
		spaces++;
//		System.out.println(getString(spaces) + "visitClassType");
		// try checking type.findDeclaration()? to see if you can get the decl and cast
		// it to
		// the classDecl
		// Declaration temp = type.findDeclaration();
		ClassDecl classDecl = (ClassDecl) table.getClass(type.className.spelling);
		if (classDecl == null) {
			rep.reportError(
					"*** line " + type.posn.f + ": " + "visitClassType Error: The class decl is not in the table.");
			return null;
		} else {
			type.className.decl = classDecl;
			// System.out.println(getString(spaces) + "ClassType's id className has it's
			// decl updated to ClassDecl of Class: " + type.className.spelling);
		}
//		System.out.println(getString(spaces) + "visitClassType\t\t\tDONE");
		spaces--;

		// table.printStack();

		return null;
	}

	@Override
	public Object visitArrayType(ArrayType type, Work type2) {
		spaces++;
//		System.out.println(getString(spaces) + "visitArrayType");
		type.eltType.visit(this, Work.NORMAL);
//		System.out.println(getString(spaces) + "visitArrayType\t\t\tDONE");
		spaces--;

		return null;
	}

	@Override
	public Object visitBlockStmt(BlockStmt stmt, Work type2) {
		spaces++;
//		System.out.println(getString(spaces) + "visitBlockStmt");
		table.openScope();

		for (Statement statement : stmt.sl) {
			statement.visit(this, Work.NORMAL);
		}

		for (String name : table.getSmol().keySet()) {
			methodVariables.remove(name);
		}

		table.closeScope();
//		System.out.println(getString(spaces) + "visitBlockStmt\t\t\tDONE");
		spaces--;

		return null;
	}

	@Override
	public Object visitVardeclStmt(VarDeclStmt stmt, Work type) {
		spaces++;
//		System.out.println(getString(spaces) + "visitVardeclStmt");

		declaringVariable = stmt.varDecl.name;
		// System.out.println(getString(spaces) + "Current Declaring Variable Updated: "
		// + declaringVariable + " Visiting Initial Exp");

		stmt.initExp.visit(this, Work.NORMAL);
		declaringVariable = "";
		// System.out.println(getString(spaces) + "Current Declaring Variable Updated:
		// ''. Visiting stmt.varDecl");
		stmt.varDecl.visit(this, Work.NORMAL);
		// System.out.println(getString(spaces) + "visitVardeclStmt DONE");

//		System.out.println(getString(spaces) + "visitVardeclStmt\t\t\tDONE");
		spaces--;

		return null;
	}

	@Override
	public Object visitAssignStmt(AssignStmt stmt, Work type) {
		spaces++;
		if (stmt.ref.decl instanceof FieldDecl) {
			FieldDecl fieldDecl = (FieldDecl) stmt.ref.decl;
			if (fieldDecl.isStatic == true) {
				stmt.ref.decl.staticField = true;
			}
		}

		// to fix the lenght on the left
		if (stmt.ref instanceof QualRef) {
			QualRef temp = (QualRef) stmt.ref;
			while (temp.ref instanceof QualRef) {
				temp = (QualRef) temp.ref;
			}
			if (temp.id.spelling.equals("length")) {
				rep.reportError("*** line " + stmt.posn.s + ": " + "Can't have a length assignment on left hand");
			}
		}

//		System.out.println(getString(spaces) + "visitAssignStmt");
		if (stmt.ref instanceof ThisRef) {
			rep.reportError("*** line " + stmt.posn.s + ": " + "You can't do this = something");
			return null;
		} else {
			stmt.ref.visit(this, Work.NORMAL);
		}
		stmt.val.visit(this, Work.NORMAL);
		// System.out.println(getString(spaces) + "assignstmt");

		// table.printStack();
//		System.out.println(getString(spaces) + "visitAssignStmt\t\t\t");
		spaces--;

		return null;
	}

	@Override
	public Object visitIxAssignStmt(IxAssignStmt stmt, Work type) {
		spaces++;
//		System.out.println(getString(spaces) + "visitIxAssignStmt");
		if (stmt.ref instanceof ThisRef) {
			rep.reportError("*** line " + stmt.posn.s + ": " + "You can't do this = []something");
			return null;
		} else {
			stmt.ref.visit(this, Work.NORMAL);
		}
		stmt.ix.visit(this, Work.NORMAL);
		stmt.exp.visit(this, Work.NORMAL);
//		System.out.println(getString(spaces) + "visitIxAssignStmt\t\t\tDONE");
		spaces--;

		// table.printStack();

		return null;
	}

	@Override
	public Object visitCallStmt(CallStmt stmt, Work type) {
		spaces++;
//		System.out.println(getString(spaces) + "visitCallStmt");
		stmt.methodRef.visit(this, Work.NORMAL);
		MethodDecl mthd;

		if (stmt.methodRef instanceof ThisRef) {
			rep.reportError("*** line " + stmt.posn.s + ": " + "This can't be used to call a method. What is this()?");
			return null;
		}

		if (stmt.methodRef.findDeclaration() instanceof MethodDecl) {
			mthd = (MethodDecl) stmt.methodRef.findDeclaration();
		} else {
			rep.reportError("*** line " + stmt.posn.s + ": " + "The method cannot be found.");
			return null;
		}

		if (stmt.argList.size() != mthd.parameterDeclList.size()) {
			rep.reportError("*** line " + stmt.posn.s + ": "
					+ "Parameter size doesn't agree with argument size for the method.");
			return null;
		}

		for (Expression expression : stmt.argList) {
			expression.visit(this, Work.NORMAL);
		}

//		System.out.println(getString(spaces) + "visitCallStmt\t\t\tDONE");
		spaces--;

		// table.printStack();

		return null;
	}

	@Override
	public Object visitReturnStmt(ReturnStmt stmt, Work type) {
		spaces++;
		if (stmt.returnExpr != null)
			stmt.returnExpr.visit(this, Work.NORMAL);
		spaces--;
		return null;
	}

	@Override
	public Object visitIfStmt(IfStmt stmt, Work type) {
		spaces++;

		stmt.cond.visit(this, Work.NORMAL);

		if (stmt.thenStmt instanceof VarDeclStmt) {
			rep.reportError("*** line " + stmt.thenStmt.posn.f + ": "
					+ "VarDeclStmt can't be the only thing in the then statement");
			return null;
		} else {
			stmt.thenStmt.visit(this, Work.NORMAL);
		}

		if (stmt.elseStmt != null) {
			if (stmt.elseStmt instanceof VarDeclStmt) {
				rep.reportError("*** line " + stmt.elseStmt.posn.f + ": "
						+ "VarDeclStmt can't be the only thing in the else statement");
				return null;
			} else {
				stmt.elseStmt.visit(this, Work.NORMAL);
			}
		}
		spaces--;

		return null;
	}

	@Override
	public Object visitWhileStmt(WhileStmt stmt, Work type) {
		spaces++;
		stmt.cond.visit(this, Work.NORMAL);
		if (stmt.body != null) {
			if (stmt.body instanceof VarDeclStmt) {
				rep.reportError(
						"*** line " + stmt.body.posn.f + ": " + "while loop can't just have a var decl statement");
				return null;
			} else {
				stmt.body.visit(this, Work.NORMAL);
			}
		}
		spaces--;

		return null;
	}

	@Override
	public Object visitUnaryExpr(UnaryExpr expr, Work type) {
		spaces++;
		expr.expr.visit(this, Work.NORMAL);
		spaces--;

		return null;
	}

	@Override
	public Object visitBinaryExpr(BinaryExpr expr, Work type) {
		spaces++;

		expr.left.visit(this, Work.NORMAL);
		expr.right.visit(this, Work.NORMAL);
		spaces--;

		return null;
	}

	@Override
	public Object visitRefExpr(RefExpr expr, Work type) {
		spaces++;
		expr.ref.visit(this, Work.NORMAL);
		if (expr.ref instanceof IdRef && (expr.ref.findDeclaration() instanceof ClassDecl
				|| expr.ref.findDeclaration() instanceof MethodDecl)) {
			rep.reportError("*** line " + expr.posn.s + ": " + "Can't have class/method name in a RefExpr");
			return null;
		}
		spaces--;

		return null;
	}

	@Override
	public Object visitIxExpr(IxExpr expr, Work type) {
		spaces++;

		expr.ref.visit(this, Work.NORMAL);
		if (expr.ref instanceof IdRef && (expr.ref.findDeclaration() instanceof ClassDecl
				|| expr.ref.findDeclaration() instanceof MethodDecl)) {
			rep.reportError("*** line " + expr.posn.s + ": " + "Cannot reference class/method name in a IxExpr");
			return null;
		}
		expr.ixExpr.visit(this, Work.NORMAL);

		spaces--;

		return null;
	}

	@Override
	public Object visitCallExpr(CallExpr expr, Work type) {
		spaces++;
		expr.functionRef.visit(this, Work.METHOD);

		MethodDecl mD = (MethodDecl) (expr.functionRef.findDeclaration());
		if (expr.argList.size() != mD.parameterDeclList.size()) {
			rep.reportError("*** line " + expr.posn.s + ": " + "Arguments don't match with number of parameters.");
			return null;
		}
		for (Expression expression : expr.argList) {
			expression.visit(this, Work.NORMAL);
		}
		spaces--;

		return null;
	}

	@Override
	public Object visitLiteralExpr(LiteralExpr expr, Work type) {
		spaces++;

		expr.lit.visit(this, Work.NORMAL);
		spaces--;

		return null;
	}

	@Override
	public Object visitNewObjectExpr(NewObjectExpr expr, Work type) {
		spaces++;
		expr.classtype.className.visit(this, Work.NORMAL);
		spaces--;

		return null;
	}

	@Override
	public Object visitNewArrayExpr(NewArrayExpr expr, Work type) {
		spaces++;
		expr.eltType.visit(this, Work.NORMAL);
		expr.sizeExpr.visit(this, Work.NORMAL);
		spaces--;

		return null;
	}

	@Override
	public Object visitThisRef(ThisRef ref, Work type) {
		spaces++;

		if (staticMethod) {
			rep.reportError("*** line " + ref.posn.s + ": " + "can't have a this reference in a static method.");
			return null;
		}

		ref.setClassDecl(selectedClass);
		ref.stat = false;
		spaces--;

		return ref;
	}

	@Override
	public Object visitIdRef(IdRef ref, Work type) {
		spaces++;
		ref.id.visit(this, Work.NORMAL);

		if (ref.id.spelling.equals(declaringVariable)) {
			rep.reportError("*** line " + ref.id.posn.s + ": " + declaringVariable + "is not initialized");
			return null;
		}

		if (ref.id.decl instanceof MemberDecl) {

			MemberDecl memberDecl = (MemberDecl) ref.id.decl;

			if (memberDecl.cD != selectedClass) {
				System.out.println(memberDecl.name);
				System.out.println("MemberDecl's class " + memberDecl.cD.name + " Err");
				System.out.println("Selected class " + selectedClass.name + " Err");
				rep.reportError("*** line " + ref.posn.s + ": " + "Cannot find symbol: " + ref.id.spelling
						+ " under scope of class");
				return null;
			}
		}
		spaces--;
		ref.stat = ref.id.stat;
		ref.decl = ref.id.decl;
		return null;
	}

	@Override
	public Object visitQRef(QualRef ref, Work type) {
		spaces++;
		ref.ref.visit(this, Work.NORMAL);
		Declaration previousDeclaration = ref.ref.findDeclaration();
		boolean prevStat = staticMethod;
		staticMethod = ref.ref.stat;

		if (previousDeclaration == null)
			return null;
		else if (previousDeclaration instanceof MethodDecl) {
			rep.reportError("*** line " + ref.posn.s + ": " + "A qualified reference can't have a method inside.");
			return null;
		} else if (previousDeclaration instanceof ClassDecl) {
			ClassDecl cD = (ClassDecl) previousDeclaration;
			ref.id.visit(this, Work.MEMBER);
			ref.stat = ref.id.stat;
			ref.decl = ref.id.decl;

			if (ref.findDeclaration() instanceof MemberDecl) {
				if (!(cD == selectedClass)) {
					if (!findClassMember(cD, ref.findDeclaration().name, staticMethod, true)) {
						rep.reportError(
								"*** line " + ref.posn.s + ": " + "Failing referencing a static and public member.");
						return null;
					}
				} else {
					if (!findClassMember(cD, ref.findDeclaration().name, staticMethod, false)) {
						rep.reportError("*** line " + ref.posn.s + ": " + "Cannoot find member inside class");
						return null;
					}
				}
			} else {
				rep.reportError("*** line " + ref.posn.s + ": " + "We need a member declaration.");
				return null;
			}

		} else { // basically just a field declaration
			doFieldDecl(ref, previousDeclaration);
		}

		staticMethod = prevStat;
		spaces--;

		if (ref.ref instanceof IdRef) {
			if (((IdRef) ref.ref).stat) {
				((Declaration) ref.ref.findDeclaration()).staticField = true;
				ref.decl.staticField = true;
			}
		}

		ref.decl = ref.id.decl;

		return null;
	}

	public Object visitIdentifierMethod(Identifier id) {
		id.stat = false;

		Declaration decl = table.getMethod(id.spelling);
		if (decl == null) {
			rep.reportError("*** line " + id.posn.s + ": " + "visitIdentifierMethod, looking for method name.");
			return null;
		} else {
			id.decl = decl;
		}
		return null;

	}

	public Object visitIdentifierMember(Identifier id) {
		id.stat = false;

		Declaration decl = table.getMember(id.spelling);
		if (decl == null) {
			rep.reportError("*** line " + id.posn.s + ": " + "visitIdentifierMember, looking for member name.");
			return null;
		} else {
			id.decl = decl;
		}
		return null;
	}

	public Object doFieldDecl(QualRef referenceQual, Declaration pastDeclaration) {
		referenceQual.id.visit(this, Work.MEMBER);
		referenceQual.stat = referenceQual.id.stat;
		referenceQual.decl = referenceQual.id.decl;

		if (pastDeclaration.type.typeKind == TypeKind.CLASS) {
			ClassDecl cD = (ClassDecl) (pastDeclaration.type.findDeclarationForType());

			if (pastDeclaration instanceof ClassDecl)
				cD = (ClassDecl) pastDeclaration;

			if (referenceQual.findDeclaration() instanceof MemberDecl) {
				if (!(cD == selectedClass)) {
					if (cD == null) {
					} else if (!findClassMember(cD, referenceQual.findDeclaration().name, false, true)) {
						rep.reportError("*** line " + referenceQual.posn.s + ": " + "Cannot find public member: ");
						return null;
					}
				} else {
					if (!findClassMember(cD, referenceQual.findDeclaration().name, false, false)) {
						rep.reportError("*** line " + referenceQual.posn.s + ": " + "Cannot finbd member: ");
						return null;
					}
				}
			} else {
				rep.reportError("*** line " + referenceQual.posn.s + ": " + "Expect a member declaration: ");
				return null;
			}
		} else if (pastDeclaration.type.typeKind == TypeKind.ARRAY) {
			if (!referenceQual.id.spelling.equals("length")) {
				rep.reportError(
						"*** line " + referenceQual.posn.s + ": " + "Referencing a member of an array, not length either");
			} else {
				referenceQual.id.decl = arr;
				referenceQual.id.decl.isLen = true;
			}
		} else {
			rep.reportError("*** line " + referenceQual.posn.s + ": " + "Referncing member of primitive types");
			return null;
		}
		return null;
	}

	@Override
	public Object visitIdentifier(Identifier id, Work type) {
		spaces++;

		if (id.spelling.equals("length")) {
			id.decl = arr;
			return null;
		}

		if (type == Work.METHOD) {
			visitIdentifierMethod(id);
			return null;
		}

		if (type == Work.MEMBER) {
			visitIdentifierMember(id);
			return null;
		}

		id.stat = false;

		Declaration decl = table.retrieve(id.spelling);

		
		if (decl == null) {
			rep.reportError("*** line " + id.posn.s + ": " + "Decl is null: " + id.spelling);
			return null;
		} else if (decl instanceof ClassDecl) {
			id.decl = decl;
			id.stat = true;
		} else {
			if (decl instanceof MemberDecl) {
				MemberDecl mD = (MemberDecl) decl;
				if ((staticMethod && !mD.isStatic)) {
					rep.reportError(
							"*** line " + id.posn.s + ": " + "Referencing non-static members in static methods");
					return null;
				}
				if (!(selectedClass == mD.cD) && !staticMethod && mD.isStatic) {
					rep.reportError(
							"*** line " + id.posn.s + ": " + "Referencing static members in non-static methods");
					return null;
				}
			}
			decl.type.visit(this, Work.NORMAL);
			id.decl = decl;
		}
		spaces--;

		return null;
	}

	@Override
	public Object visitOperator(Operator op, Work type) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object visitIntLiteral(IntLiteral num, Work type) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object visitBooleanLiteral(BooleanLiteral bool, Work type) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object visitNullLiteral(NullLiteral nul, Work type) {
		// TODO Auto-generated method stub
		return null;
	}

	public String getString(int spaces) {
		spaces *= 3;
		String st = "";

		for (int i = 0; i < spaces; i++) {
			st += " ";
		}

		return st;
	}

	public boolean findClassMember(ClassDecl cD, String name, boolean stat, boolean pub) {
		for (FieldDecl fD : cD.fieldDeclList) {
			if (name.equals(fD.name) && !(stat && !fD.isStatic) && !(pub && fD.isPrivate))
				return true;
		}

		for (MethodDecl mD : cD.methodDeclList) {
			if (name.equals(mD.name) && !(stat && !mD.isStatic) && !(pub && mD.isPrivate))
				return true;
		}
		return false;
	}

}
