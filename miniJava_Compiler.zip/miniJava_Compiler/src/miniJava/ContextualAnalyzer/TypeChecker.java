package miniJava.ContextualAnalyzer;

import miniJava.*;
import miniJava.AbstractSyntaxTrees.*;
import miniJava.AbstractSyntaxTrees.Package;
import miniJava.SyntacticAnalyzer.SourcePosition;
import miniJava.SyntacticAnalyzer.TokenKind;

public class TypeChecker implements Visitor<Object, TypeDenoter> {
	private AST ast;
	public IdentificationTable table;
	public ErrorReporter rep;
	private SourcePosition posn = null;
	private SourcePosition retPosn = null;
	private boolean lastReturn = false;
	TypeDenoter retType;

	public TypeChecker(AST ast, ErrorReporter rep) {
		this.ast = ast;
		this.rep = rep;
	}

	public AST start() {
		ast.visit(this, null);
		return ast;
	}

	@Override
	public TypeDenoter visitPackage(Package prog, Object arg) {
		ClassDeclList cdList = prog.classDeclList;
		for (ClassDecl decl : cdList) {
			decl.visit(this, null);
		}
		return null;
	}

	@Override
	public TypeDenoter visitClassDecl(ClassDecl cd, Object arg) {
		FieldDeclList fdList = cd.fieldDeclList;
		MethodDeclList mdList = cd.methodDeclList;

		for (FieldDecl fd : fdList) {
			fd.visit(this, null);
		}

		for (MethodDecl md : mdList) {
			md.visit(this, null);
		}

		return null;
	}

	@Override
	public TypeDenoter visitFieldDecl(FieldDecl fd, Object arg) {
		// nothing really matters here i'm assuming. unless we need to store the type
		// that is being returned
		// but that's already stored in the fd.type
		return fd.type.visit(this, null);
	}

	@Override
	public TypeDenoter visitMethodDecl(MethodDecl md, Object arg) {
		md.type = md.type.visit(this, null);

		ParameterDeclList pdList = md.parameterDeclList;
		StatementList stList = md.statementList;

		for (ParameterDecl pd : pdList) {
			pd.visit(this, null);
		}

//		for (Statement st : stList) {
//			st.visit(this, null);
//		}
		
		int lastReturnPos = 0;
		for (int i = 0; i < stList.size(); i++) {
			Statement st = stList.get(i);
			if (i == (stList.size()-1)) {
				lastReturn = st instanceof ReturnStmt ? true : false;
				lastReturnPos = lastReturn ? st.posn.s : 0;
			}
			st.visit(this, null);
		}

		if (md.type.typeKind == TypeKind.VOID) {
			if (retType != null) {
				rep.reportError("*** line " + retPosn.s + ": " + "Cannot have a return statement in a void method.");
				return new BaseType(TypeKind.ERROR, md.posn);
			}
		} else {
			if ((!(checkType(retType, md.type))) || !lastReturn) {
				rep.reportError("*** line " + lastReturnPos + ": " + "Return and method type don't match. Or the last statement is not return.");
				return new BaseType(TypeKind.ERROR, md.posn);
			}
		}

		return null;
	}

	@Override
	public TypeDenoter visitParameterDecl(ParameterDecl pd, Object arg) {
		pd.type.visit(this, null);
		return null;
	}

	@Override
	public TypeDenoter visitVarDecl(VarDecl decl, Object arg) {
		return decl.type.visit(this, null);
	}

	@Override
	public TypeDenoter visitBaseType(BaseType type, Object arg) {
		return type;
	}

	@Override
	public TypeDenoter visitClassType(ClassType type, Object arg) {
		return type;
	}

	@Override
	public TypeDenoter visitArrayType(ArrayType type, Object arg) {
		// System.out.println(type.typeKind);
		return type;
	}

	@Override
	public TypeDenoter visitBlockStmt(BlockStmt stmt, Object arg) {
		StatementList stList = stmt.sl;

		for (Statement st : stList) {
			st.visit(this, null);
		}

		return null;
	}

	@Override
	public TypeDenoter visitVardeclStmt(VarDeclStmt stmt, Object arg) {
		TypeDenoter varType = stmt.varDecl.visit(this, null);
		TypeDenoter expType = stmt.initExp.visit(this, null);

		if (varType.typeKind == TypeKind.CLASS && expType.typeKind == TypeKind.CLASS) {
			if (stmt.initExp instanceof NewObjectExpr) {
				Identifier cn1 = ((ClassType) varType).className;
				Identifier cn2 = ((ClassType) expType).className;
				if (!cn1.spelling.equals(cn2.spelling)) {
					rep.reportError("*** line " + stmt.initExp.posn.f + ": " + "Classes don't match in equality.");
					return new BaseType(TypeKind.ERROR, stmt.posn);
				}
			}
		}

		if (stmt.initExp instanceof RefExpr) {
			RefExpr r = (RefExpr) stmt.initExp;
			if (r.ref instanceof QualRef) {
				QualRef q = (QualRef) r.ref;
				if (q.findDeclaration() instanceof MethodDecl) {
					rep.reportError("*** line " + stmt.initExp.posn.s + ": "
							+ "You cannot have a Reference Exp for a Method Decl. Should be a call Expr.");
					return new BaseType(TypeKind.ERROR, stmt.posn);
				}
			}
		}

		if (expType.typeKind != TypeKind.NUL) {
			if (stmt.initExp instanceof RefExpr) {
				RefExpr refExpr = (RefExpr) stmt.initExp;
				if (refExpr.ref.decl instanceof ClassDecl) {
					rep.reportError("*** line " + stmt.initExp.posn.s + ": " + "class error in varDecl");
					return new BaseType(TypeKind.ERROR, stmt.posn);
				}

				if (refExpr.ref.decl instanceof MethodDecl) {
					rep.reportError("*** line " + stmt.initExp.posn.s + ": " + "method error in varDecl");
					return new BaseType(TypeKind.ERROR, stmt.posn);
				}
			}

			if (!checkType(varType, expType)) {
				rep.reportError("*** line " + stmt.posn.s + ": " + "Types don't match in VardeclStmt.");
				return new BaseType(TypeKind.ERROR, stmt.posn);
			}
			// return new BaseType(TypeKind.ERROR, posn);
		}

		return null;
	}

	@Override
	public TypeDenoter visitAssignStmt(AssignStmt stmt, Object arg) {
		TypeDenoter refType = stmt.ref.visit(this, null);
		TypeDenoter valType = stmt.val.visit(this, null);
		if (refType.typeKind == TypeKind.CLASS && valType.typeKind == TypeKind.CLASS) {
			if (stmt.val instanceof NewObjectExpr) {
				Identifier cn1 = ((ClassType) refType).className;
				//System.out.println(valType);
				Identifier cn2 = ((ClassType) valType).className;
				if (!cn1.spelling.equals(cn2.spelling)) {
					rep.reportError("*** line " + stmt.val.posn.s + ": " + "Classes don't match in equality.");
					return new BaseType(TypeKind.ERROR, stmt.posn);
				}
			}
		}

		if (valType.typeKind != TypeKind.NUL && !checkType(refType, valType)) {
			rep.reportError("*** line " + stmt.posn.s + ": " + "You got an error in the AssignStatement");
			return new BaseType(TypeKind.ERROR, stmt.posn);
		}

		return null;
	}

	@Override
	public TypeDenoter visitIxAssignStmt(IxAssignStmt stmt, Object arg) {
		TypeDenoter refType = stmt.ref.visit(this, null);
		TypeDenoter ixType = stmt.ix.visit(this, null);
		TypeDenoter expType = stmt.exp.visit(this, null);

		ArrayType arr = null;
		ArrayType arr2 = null;

		boolean a1 = false;
		boolean a2 = false;

		if (refType.typeKind == TypeKind.ARRAY) {
			arr = ((ArrayType) stmt.ref.findDeclaration().type);
			a1 = true;
		}

		if (expType.typeKind == TypeKind.ARRAY) {
			arr2 = ((ArrayType) ((IxExpr) stmt.exp).ref.findDeclaration().type);
			a2 = true;
		}

		if (a1 && !a2) {
			if (expType.typeKind != TypeKind.NUL) {
				if (!checkType(arr.eltType, expType)) {
					rep.reportError("*** line " + stmt.posn.s + ": "
							+ "Your expression is neither null, nor a proper array type.");
					return new BaseType(TypeKind.ERROR, stmt.posn);
				}
			}
		} else if (a1 && a2) {
			if (!checkType(arr, arr2)) {
				rep.reportError("*** line " + stmt.posn.s + ": " + "Both arrays but not similar types yo.");
				return new BaseType(TypeKind.ERROR, stmt.posn);
			}
		} else if (!a1 && a2) {
			if (!checkType(refType, arr2.eltType)) {
				rep.reportError("*** line " + stmt.posn.s + ": " + "Your reference doesn't match the array type.");
				return new BaseType(TypeKind.ERROR, stmt.posn);
			}
		} else {
			rep.reportError("*** line " + stmt.posn.s + ": " + "One type must be array.");
			return new BaseType(TypeKind.ERROR, stmt.posn);
		}

		return null;
	}

	@Override
	public TypeDenoter visitCallStmt(CallStmt stmt, Object arg) {
		ParameterDeclList pl = ((MethodDecl) stmt.methodRef.findDeclaration()).parameterDeclList;
		ExprList al = stmt.argList;

		if (pl.size() != stmt.argList.size()) {
			rep.reportError("*** line " + stmt.posn.s + ": " + "Paramter Count doesn't match for Call Statement");
			return new BaseType(TypeKind.ERROR, stmt.posn);
		} else {
			for (int i = 0; i < al.size(); i++) {
				if (!checkType(pl.get(i).type.visit(this, null), al.get(i).visit(this, null))) {
					rep.reportError(
							"*** line " + stmt.posn.s + ": " + "Argument types don't match for Call Statement.");
					return new BaseType(TypeKind.ERROR, stmt.posn);
				}
			}
		}

		return null;
	}

	@Override
	public TypeDenoter visitReturnStmt(ReturnStmt stmt, Object arg) {
		if (stmt.returnExpr != null) {
			retType = stmt.returnExpr.visit(this, null);
		}
		retPosn = stmt.returnExpr.posn;
		return null;
	}

	@Override
	public TypeDenoter visitIfStmt(IfStmt stmt, Object arg) {
		if (stmt.cond.visit(this, null).typeKind != TypeKind.BOOLEAN) {
			rep.reportError("*** line " + stmt.cond.posn.s + ": " + "If conditional doesn't evaluate to true/false.");
			return new BaseType(TypeKind.ERROR, stmt.posn);
		}
		stmt.thenStmt.visit(this, null);
		if (stmt.elseStmt != null)
			stmt.elseStmt.visit(this, null);
		return null;
	}

	@Override
	public TypeDenoter visitWhileStmt(WhileStmt stmt, Object arg) {
		if (stmt.cond.visit(this, null).typeKind != TypeKind.BOOLEAN) {
			rep.reportError("*** line " + stmt.cond.posn.s + ": " + "If conditional doesn't evaluate to true.");
			return new BaseType(TypeKind.ERROR, stmt.posn);
		}
		stmt.body.visit(this, null);
		return null;
	}

	@Override
	public TypeDenoter visitUnaryExpr(UnaryExpr expr, Object arg) {
		if (expr.operator.kind != TokenKind.NOT && expr.operator.kind != TokenKind.NEGATE) {
			rep.reportError("*** line " + expr.posn.s + ": " + "Unary Expression has an incorrect operator");
			return new BaseType(TypeKind.ERROR, expr.posn);
		} else {
			if (expr.operator.kind == TokenKind.NOT) {
				if (expr.expr.visit(this, null).typeKind != TypeKind.BOOLEAN) {
					rep.reportError("*** line " + expr.posn.s + ": "
							+ "If you have a NOT Unary Expr, then the Expr must be have a BOOLEAN value.");
					return new BaseType(TypeKind.ERROR, expr.posn);
				} else {
					return new BaseType(TypeKind.BOOLEAN, expr.posn);
				}
			} else {
				if (expr.expr.visit(this, null).typeKind != TypeKind.INT) {
					rep.reportError("*** line " + expr.posn.s + ": "
							+ "If you have a NOT Unary Expr, then the Expr must be have a INT value.");
					return new BaseType(TypeKind.ERROR, expr.posn);
				} else {
					return new BaseType(TypeKind.INT, expr.posn);
				}
			}
		}
	}

	@Override
	public TypeDenoter visitBinaryExpr(BinaryExpr expr, Object arg) {
		TypeDenoter type1 = expr.left.visit(this, null);
		TypeDenoter type2 = expr.right.visit(this, null);

		TokenKind op = expr.operator.kind;

		if (type1.typeKind == TypeKind.NUL || type2.typeKind == TypeKind.NUL) {
			boolean nt1 = false;
			boolean nt2 = false;

			if (type1.typeKind == TypeKind.NUL)
				nt1 = true;

			if (type2.typeKind == TypeKind.NUL)
				nt2 = true;

			switch (op) {
			case DIS:
			case CON:
			case GTE:
			case LTE:
			case LT:
			case GT:
				if (nt1 && nt2) {
					rep.reportError(
							"*** line " + expr.posn.s + ": " + "You can't have both expressions equal null type");
					return new BaseType(TypeKind.ERROR, expr.posn);
				} else {
					return new BaseType(TypeKind.BOOLEAN, expr.posn);
				}
			case ADDITIVE:
			case MULTIPLY:
			case NEGATE:
			case DIVIDE:
				if (nt1 && nt2) {
					rep.reportError(
							"*** line " + expr.posn.s + ": " + "You can't have both expressions equal null type");
					return new BaseType(TypeKind.ERROR, expr.posn);
				} else {
					return new BaseType(TypeKind.INT, expr.posn);
				}
			case EQUALSEQUALS:
			case NOTEQUALS:
				if (nt1 && nt2) {
					rep.reportError(
							"*** line " + expr.posn.s + ": " + "You can't have both expressions equal null type");
					return new BaseType(TypeKind.ERROR, expr.posn);
				} else {
					return new BaseType(TypeKind.BOOLEAN, expr.posn);
				}
			default:
				return new BaseType(TypeKind.UNSUPPORTED, expr.posn);
			}
		}
		
		if (!checkType(type1, type2)) {
			rep.reportError(
					"*** line " + expr.posn.s + ": " + "The left bin exp and the right bin exp don't agree in type yo");
			return new BaseType(TypeKind.ERROR, expr.posn);
		} else {
			switch (op) {
			case DIS:
				if (type1.typeKind != TypeKind.BOOLEAN) {
					rep.reportError(
							"*** line " + expr.posn.s + ": " + "Arguments don't match the DISJUNCTION operator");
					return new BaseType(TypeKind.ERROR, expr.posn);
				}
				return new BaseType(TypeKind.BOOLEAN, expr.posn);
			case CON:
				if (type1.typeKind != TypeKind.BOOLEAN) {
					rep.reportError(
							"*** line " + expr.posn.s + ": " + "Arguments don't match the CONJUNCTION operator");
					return new BaseType(TypeKind.ERROR, expr.posn);
				}
				return new BaseType(TypeKind.BOOLEAN, expr.posn);
			case EQUALSEQUALS:
			case NOTEQUALS:
				if (type1.typeKind == TypeKind.CLASS && type2.typeKind == TypeKind.CLASS) {
					Identifier cn1 = ((ClassType) type1).className;
					Identifier cn2 = ((ClassType) type2).className;
					if (!cn1.spelling.equals(cn2.spelling)) {
						rep.reportError("*** line " + expr.posn.s + ": " + "Classes don't match in equality.");
						return new BaseType(TypeKind.ERROR, expr.posn);
					}
				}
				return new BaseType(TypeKind.BOOLEAN, expr.posn);
			case GT:
			case LT:
			case GTE:
			case LTE:
				if (type1.typeKind != TypeKind.INT) {
					rep.reportError(
							"*** line " + expr.posn.s + ": " + "Arguments don't match in the RELATIONAL operator.");
					return new BaseType(TypeKind.ERROR, expr.posn);
				}
				return new BaseType(TypeKind.BOOLEAN, expr.posn);
			case ADDITIVE:
				if (type1.typeKind != TypeKind.INT) {
					rep.reportError(
							"*** line " + expr.posn.s + ": " + "Arguments don't match in the ADDITIVE operator.");
					return new BaseType(TypeKind.ERROR, expr.posn);
				}
				return new BaseType(TypeKind.INT, posn);
			case MULTIPLY:
			case DIVIDE:
				if (type1.typeKind != TypeKind.INT) {
					rep.reportError(
							"*** line " + expr.posn.s + ": " + "Arguments don't match in the MULTIPLICATIVE operator.");
					return new BaseType(TypeKind.ERROR, expr.posn);
				}
				return new BaseType(TypeKind.INT, posn);
			case NEGATE:
				if (type1.typeKind != TypeKind.INT && type2.typeKind != TypeKind.INT) {
					rep.reportError("*** line " + expr.posn.s + ": " + "Arguments don't match in the NEGATE operator.");
					return new BaseType(TypeKind.ERROR, expr.posn);
				}
				return new BaseType(TypeKind.INT, posn);
			default:
				rep.reportError("*** line " + expr.posn.s + ": " + "Unsupported operation type");
				return new BaseType(TypeKind.UNSUPPORTED, expr.posn);
			}
		}
	}

	@Override
	public TypeDenoter visitRefExpr(RefExpr expr, Object arg) {
		if (expr != null) {
			return expr.ref.visit(this, null);
		}
		return new BaseType(TypeKind.NUL, expr.posn);
	}

	@Override
	public TypeDenoter visitIxExpr(IxExpr expr, Object arg) {
		if (expr.ref.findDeclaration().type instanceof ArrayType) {
			TypeDenoter type = expr.ixExpr.visit(this, null);
			
			
			if (type.typeKind != TypeKind.INT || type.typeKind == TypeKind.ERROR || type == null) {
				//System.out.println(((IdRef)((RefExpr)expr.ixExpr).ref).id.spelling);
				System.out.println(type.typeKind);
				rep.reportError("*** line " + expr.posn.s + ": " + "You need to have an integer value in the [].");
				return new BaseType(TypeKind.ERROR, expr.posn);
			}

			return ((ArrayType) expr.ref.findDeclaration().type).eltType;
		} else {
			rep.reportError("*** line " + expr.posn.s + ": " + "You can't call an array, when it's not an array.");
			return new BaseType(TypeKind.ERROR, expr.posn);
		}

	}

	@Override
	public TypeDenoter visitCallExpr(CallExpr expr, Object arg) {
		ParameterDeclList pl = ((MethodDecl) expr.functionRef.findDeclaration()).parameterDeclList;
		ExprList al = expr.argList;

		if (pl.size() != expr.argList.size()) {
			rep.reportError("*** line " + expr.posn.s + ": " + "Paramter Count doesn't match for Call Statement");
			return new BaseType(TypeKind.ERROR, expr.posn);
		} else {
			for (int i = 0; i < al.size(); i++) {
				if (!checkType(pl.get(i).type.visit(this, null), al.get(i).visit(this, null))) {
					rep.reportError(
							"*** line " + expr.posn.s + ": " + "Argument types don't match for Call Statement.");
					return new BaseType(TypeKind.ERROR, expr.posn);
				}
			}
			return new BaseType(((MethodDecl) expr.functionRef.findDeclaration()).type.typeKind, posn);
		}
	}

	@Override
	public TypeDenoter visitLiteralExpr(LiteralExpr expr, Object arg) {
		return expr.lit.visit(this, null);
	}

	@Override
	public TypeDenoter visitNewObjectExpr(NewObjectExpr expr, Object arg) {
		return expr.classtype.visit(this, null);
	}

	@Override
	public TypeDenoter visitNewArrayExpr(NewArrayExpr expr, Object arg) {
		return new ArrayType(expr.eltType, posn);
	}

	@Override
	public TypeDenoter visitThisRef(ThisRef ref, Object arg) {
		if (ref.decl != null) {
			return ref.decl.type;
		} else {
			return new BaseType(TypeKind.THIS, posn);
		}
	}

	@Override
	public TypeDenoter visitIdRef(IdRef ref, Object arg) {
		if (ref.id.decl != null) {
			return ref.id.decl.type;
		}
		return new BaseType(TypeKind.ERROR, posn);
	}

	@Override
	public TypeDenoter visitQRef(QualRef ref, Object arg) {
		if (ref != null) {
			return ref.id.decl.type;
		}
		return new BaseType(TypeKind.ERROR, posn);

	}

	@Override
	public TypeDenoter visitIdentifier(Identifier id, Object arg) {
		return id.decl.type;
	}

	@Override
	public TypeDenoter visitOperator(Operator op, Object arg) {
		return null;
	}

	@Override
	public TypeDenoter visitIntLiteral(IntLiteral num, Object arg) {
		return new BaseType(TypeKind.INT, posn);
	}

	@Override
	public TypeDenoter visitBooleanLiteral(BooleanLiteral bool, Object arg) {
		return new BaseType(TypeKind.BOOLEAN, posn);
	}

	public boolean checkType(TypeDenoter type, TypeDenoter type2) {
		if (type == null || type2 == null)
			return false;

		if (type.typeKind == TypeKind.CLASS && type2.typeKind == TypeKind.THIS)
			return true;

		if (type2.typeKind == TypeKind.CLASS && type.typeKind == TypeKind.THIS)
			return true;

		if (type.typeKind == TypeKind.ERROR || type2.typeKind == TypeKind.ERROR) {
			return true;
		} else if (type.typeKind == TypeKind.UNSUPPORTED || type2.typeKind == TypeKind.UNSUPPORTED) {
			return false;
		}

		return type.typeKind == type2.typeKind;
	}

	@Override
	public TypeDenoter visitNullLiteral(NullLiteral nul, Object arg) {
		return new BaseType(TypeKind.NUL, posn);
	}

}
