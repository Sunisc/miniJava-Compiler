package miniJava;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import miniJava.ErrorReporter;
import miniJava.SyntacticAnalyzer.Parser;
import miniJava.SyntacticAnalyzer.Scanner;
import miniJava.AbstractSyntaxTrees.ASTDisplay;
import miniJava.AbstractSyntaxTrees.Package;
import miniJava.CodeGenerator.Generator;
import miniJava.ContextualAnalyzer.IdentificationChecker;
import miniJava.ContextualAnalyzer.IdentificationTable;
import miniJava.ContextualAnalyzer.TypeChecker;

public class Compiler {
	public static void main(String[] args) {
		InputStream iS = null;
		try {
			iS = new FileInputStream(args[0]);
		} catch (FileNotFoundException e) {
			System.out.println("Input file " + args[0] + " not found");
			System.exit(3);
		}

		ErrorReporter rp = new ErrorReporter();
		Scanner sc = new Scanner(iS, rp);
		Parser pr = new Parser(sc, rp);

		System.out.println("Syntactic analysis ... ");

		Package parsedPackageToBuildAST = null;
		try {
			parsedPackageToBuildAST = pr.parse();

		} catch (Exception e) {
		}

		System.out.print("Syntactic analysis complete: ");

		if (rp.hasErrors()) {
			System.out.println("INVALID miniJava expression");
//			new ASTDisplay().showTree(parsedPackageToBuildAST);
			System.exit(4);
		} else {
			System.out.println("valid miniJava expression");
//			new ASTDisplay().showTree(parsedPackageToBuildAST);
		}
		
		new ASTDisplay().showTree(parsedPackageToBuildAST);

		
		try {
		System.out.println("IdentificationChecking START");
			IdentificationTable tbl = new IdentificationTable();
			IdentificationChecker idChecker = new IdentificationChecker(parsedPackageToBuildAST, rp, tbl);
			idChecker.check();
			System.out.println("\nIdentificationChecking DONE");
			if (!rp.hasErrors()) {
				System.out.println("\nTypeChecking START");
				TypeChecker typeChecker = new TypeChecker(parsedPackageToBuildAST, rp);
				typeChecker.start();
				System.out.println("\nTypeChecking DONE");
			}
		} catch (Exception e) {
		}
		
		if (rp.hasErrors()) {
			System.out.println("\nId or Type error");
			System.exit(4);
		} else {
			System.out.println("\nValid ID + TYPE");
		}

		Generator gen = new Generator(parsedPackageToBuildAST, rp, args[0]);
		gen.createAssembly();
		
		if (rp.hasErrors()) {
			System.out.println("\nCode generator error.");
			System.exit(4);
		} else {
			System.out.println("\nCode generation successful.");
			System.exit(0);
		}
		
		
		
	}

}
